export const customTokenThemeRules = [
    {token: 'custom-negation.gitignore', foreground: 'c00ce0'}
];