#pragma once

bool initializeCOMSecurity(const wchar_t* securityDescriptor);
