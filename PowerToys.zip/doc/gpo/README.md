# Group Policies

Since version 0.64, PowerToys is released on GitHub with [Administrative Templates that allows you to configure PowerToys using Group Policies](/previous-versions/windows/desktop/policy/group-policy-objects). You can get the group policy files in each release of PowerToys over at <https://github.com/microsoft/PowerToys/releases>.

For detailed instructions and notes, head over to [learn.microsoft.com](https://aka.ms/PowerToysOverview_GPO) and see the PowerToys Group Policy section.
