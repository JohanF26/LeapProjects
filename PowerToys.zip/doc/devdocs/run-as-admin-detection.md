# This file has been moved

[PowerToys and running as Administrator](https://aka.ms/powertoysDetectedElevatedHelp)
