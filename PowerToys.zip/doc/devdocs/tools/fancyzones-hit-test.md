# [FancyZone hit test tool](/tools/FancyZone_HitTest/)

![Image of the FancyZones hit test tool](/doc/images/tools/fancyzones-hit-test.png)

This tool tests the FancyZones layout selection logic. It displays a window with 5 zones. By hovering the mouse over the zones, the zone under the mouse cursor is highlighted. The sidebar shows different metrics that are used to determine which zone is under the mouse cursor.
