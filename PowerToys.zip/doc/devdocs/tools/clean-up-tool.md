# [CleanUp_tool](/tools/CleanUp_tool/) and [CleanUp_tool_powershell_script](/tools/CleanUp_tool_powershell_script/CleanUp_tool.ps1)

This tool, respective this powershell script, is used to clean up the PowerToys installation. It cleans the `AppData` folder and the registry.

This tool is currently very outdated and just cleans up the registry keys of some few modules.
