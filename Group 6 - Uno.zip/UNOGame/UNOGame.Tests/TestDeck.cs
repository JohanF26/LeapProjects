﻿namespace UNOGame.Tests
{
    [TestClass]
    public sealed class TestDeck
    {
        [TestMethod]
        public void CreateRedCards_ShouldAddRedNumberCard()
        {
            //Arrange - set up the object, data, and conditions for the test
            var deck = new Deck();
          

            //Act - perform the action or behavior to be tested
            var cards = typeof(Deck)
                .GetField("cards", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static)
                .GetValue(null) as List<Card>;
            //Assert - verify that the action or behavior works as expected
            Assert.IsNotNull(cards);
            Assert.AreEqual(19, cards.Count);
            Assert.IsInstanceOfType(cards.First(), typeof(NumberCard));
            Assert.AreEqual(0, ((NumberCard)cards.First()).Number);
            Assert.AreEqual('r', ((NumberCard)cards.First()).Color);
        }
    }
    
}
