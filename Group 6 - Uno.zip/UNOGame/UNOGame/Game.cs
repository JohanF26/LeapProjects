﻿
namespace UNOGame
{
    public class Game
    {
        public Deck CardDeck { get; private set; }
        public List<Player> Players { get; private set; }
        public List<Card> DiscardPile { get; private set; }
        public int CurrentPlayerIndex { get; private set; }
        public GameState gameState { get; private set; }


        #region GAME_SETUP
        public Game()
        {
            CardDeck = new Deck();
            Players = new List<Player>();
            DiscardPile = new List<Card>();
            CurrentPlayerIndex = 0;
            gameState = GameState.NotStarted;
        }

        public void InitializeGame(List<string> playerNames)
        {
            InitializePlayers(playerNames);
            InitializeDeck();
            InitializeDiscardPile();
            InitializeHands();
        }

        private void InitializePlayers(List<string> playerNames)
        {
            foreach (string name in playerNames)
            {
                Players.Add(new Player(name));
            }
        }

        public void InitializeHands()
        {
            foreach (Player player in Players)
            {
                player.InitializeHand(CardDeck.Draw(7));
            }
        }

        public void InitializeDeck()
        {
            Deck.InitializeDeck();
            CardDeck.Shuffle();
        }

        public void InitializeDiscardPile()
        {
            DiscardPile.Add(CardDeck.Draw());
        }
        #endregion

        //game actions
        public void DrawCard()
        {
            //CardDeck.Draw method should pop the card from the deck
            Players[CurrentPlayerIndex].AddCard(CardDeck.Draw());
            //if the player has drawn a card, they can't have UNO anymore
            if (Players[CurrentPlayerIndex].UnoFlag)
            {
                Players[CurrentPlayerIndex].ResetUnoFlag();
            }
            Players[CurrentPlayerIndex].CanEndTurn = true;
        }

        //let the user know through the view if they made a valid play
        public bool PlayCard(int cardIndex)
        {
            //Player.PlayCard method should pop the card from the player's hand
            Card topCard = DiscardPile.Last();
            Card? playedCard = Players[CurrentPlayerIndex].PlayCard(cardIndex, topCard);
            if(playedCard != null)
            {
                DiscardPile.Add(playedCard);
                Players[CurrentPlayerIndex].CanEndTurn = true;
                CheckWin();
                return true;
            }
            return false;
            
        }

        public bool SayUNO()
        {
            return (Players[CurrentPlayerIndex].SayUNO());
        }

        public bool SayUnoToPlayer(int playerIndex)
        {
            if (!Players[playerIndex].UnoFlag && Players[playerIndex].Hand.Count == 1)
            {
                //if player has not said UNO and has only one card, they have to draw 2 cards
                Players[playerIndex].Hand.AddRange(CardDeck.Draw(2));
                return true;
            } else
            {
                //can't say UNO to a player who has already said UNO or has more than one card
                return false;
            }
        }

        public List<Card> GetCurrentPlayerCards()
        {
            return Players[CurrentPlayerIndex].Hand;
        }

        public bool CheckWin()
        {
            if(Players[CurrentPlayerIndex].Hand.Count == 0)
            {
                gameState = GameState.GameFinished;
                return true;
            }
            
            return false;
        }

        public void StartTurn()
        {
            gameState = GameState.TurnStarted;
        }

        //function to end turn
        public void EndTurn()
        {
            Players[CurrentPlayerIndex].CanEndTurn = false;
            Players[CurrentPlayerIndex].Played = false;
            //check if the player has won
            if (CheckWin())
            {
                return;
            }

            //otherwise move to the next player and end the turn
            CurrentPlayerIndex = (CurrentPlayerIndex + 1) % Players.Count;
            gameState = GameState.TurnEnded;
        }
    }
}