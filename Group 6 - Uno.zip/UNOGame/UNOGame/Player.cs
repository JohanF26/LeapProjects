﻿
namespace UNOGame
{
    public class Player
    {
        private static int counter = 0;
        public int PlayerID;
        public string Name { get; private set; }
        public List<Card> Hand { get; private set; }
        public bool UnoFlag {  get; private set; }
        public bool CanEndTurn { get; set; }
        public bool Played { get; set; }

        public Player(string name)
        {
            Name = name;
            Hand = new List<Card>();
            UnoFlag = false;
            CanEndTurn = false;
            Played = false;
            PlayerID = counter++;
        }

        public void InitializeHand(List<Card> hand)
        {
            Hand.AddRange(hand);
        }

        public void AddCard(Card card)
        {
            Hand.Add(card);
        }

        public Card? PlayCard(int cardIndex, Card topCard)
        {
            if (Hand[cardIndex].isValid(topCard))
            {
                Card cardToPlay = Hand[cardIndex];
                Hand.RemoveAt(cardIndex);
                Played = true;
                return cardToPlay;
            }
            return null;
        }

        public bool SayUNO()
        {
            if (Hand.Count == 1)
            {
                UnoFlag = true;
                return true;
            }
            return false;
        }

        public void ResetUnoFlag()
        {
            UnoFlag = false;
        }

        public List<Card> GetValidCards(Card topCard)
        {
            List<Card> validCards = new List<Card>();
            foreach (var card in Hand)
            {
                if (card.isValid(topCard))
                {
                    validCards.Add(card);
                }
            }
            return validCards;
        }


    }
}