﻿namespace UNOGame
{
    public enum GameState
    {
        NotStarted,
        TurnStarted,
        TurnEnded,
        GameFinished
        
    }
}