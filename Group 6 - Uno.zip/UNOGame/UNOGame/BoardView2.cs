﻿
using System;
using System.Collections.Generic;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace UNOGame
{
    public class BoardView2
    {
        // Update Friday Morning - New file
        public void DisplayTable(List<string> playerNames,
            List<int> pCardCnt, Card topCard, List<Card> playerHand)
        {
            Console.WriteLine("Current Table");

            if (topCard is NumberCard)
            {
                SetConsoleColor(topCard.Color);
                Console.WriteLine($"Top of Deck: [{((NumberCard)topCard).Number}]");
            }
            else
            {
                Console.WriteLine($"TopCard: {topCard.Color}");
            }
            Console.ResetColor(); // Reset to default color
            Console.WriteLine("------------------------------");

            foreach (var name in playerNames)
            {
                Console.Write($"Player: {name}  cards: ");
                foreach (var card in playerHand)
                    if (card is NumberCard)
                    {
                        SetConsoleColor(card.Color);
                        Console.Write($"[{((NumberCard)card).Number}]  ");
                        Console.ResetColor(); // Reset to default colors            
                    }
                Console.WriteLine();
            }

            Console.WriteLine("------------------------------");

        }

        public void DisplayPlayerHand(string playerName, List<Card> playerHand)
        {
            Console.Write($"{playerName} Hand:");
            foreach (var card in playerHand)
            {
                if (card is NumberCard)
                {
                    SetConsoleColor(card.Color);
                    // Console.Write($"   [{card.Color} {((NumberCard)card).Number}]  ");
                    Console.Write($"   [{((NumberCard)card).Number}]  ");
                    Console.ResetColor(); // Reset to default colors
                }
                Console.ResetColor(); // Reset to default colors            
            }
            Console.WriteLine();
        }
        public void SetConsoleColor(char color)
        {
            switch (color)
            {
                case 'r':
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case 'b':
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case 'g':
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case 'y':
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }
        }
        // ============================================
        public void WelcomePage()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("************************************");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("*                                  *");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("*      Welcome to the UNO          *");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("*          Card Game!              *");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("*                                  *");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("************************************");
            Console.ResetColor();
            Thread.Sleep(5000);
        }
        public void FlashingScreen()
        {
            Console.Title = "Flashing Screen Example";

            // Change the background color to red
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to blue
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to yellow
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to red
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to blue
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Thread.Sleep(300); // Wait for 500 milliseconds
            Console.Clear();
        }

    }
}
