﻿using System;
using UNOGame;

namespace UNOGame
{
    class Program
    {
        static void Main(string[] args)
        {

            GameController gameController = new GameController();
            gameController.StartGame();
        }
    }
}

//var board = new BoardView();
//var cards = new List<Card>();
//cards.Add(new NumberCard(1,'b'));
//cards.Add(new NumberCard(2, 'y'));
//cards.Add(new NumberCard(3, 'g'));

//board.DisplayCardsHorizontally(cards, 6, 5);
