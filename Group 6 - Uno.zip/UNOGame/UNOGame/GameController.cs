﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UNOGame
{
    public class GameController
    {
        Game UnoGame;
        BoardView BoardIO;

        public GameController()
        {
            UnoGame = new Game();
            BoardIO = new BoardView();
        }

        private void PlayCOMPlayerTurn(Player COM)
        {
            Card topCard = UnoGame.DiscardPile.Last();

            //see which players have 1 card left and haven't said UNO
            SayUnoToAll(COM);

            //play a card
            List<Card> cards = COM.GetValidCards(topCard);
            if (cards.Count > 0)
            {
                Random random = new Random();
                int cardIndex = random.Next(cards.Count);
                Card cardToPlay = cards[cardIndex];
                int cardIndexToPlay = COM.Hand.IndexOf(cardToPlay);
                UnoGame.PlayCard(cardIndexToPlay);
            }
            else
            {
                UnoGame.DrawCard();
                //if the card drawn is valid, play it
                if (COM.Hand.Last().isValid(topCard))
                {
                    UnoGame.PlayCard(COM.Hand.Count - 1);
                }
            }

            //if the player has 1 card left, say UNO
            if (COM.Hand.Count == 1)
            {
                UnoGame.SayUNO();
            }

            //end turn
            UnoGame.EndTurn();
        }

        private bool SayUnoToAll(Player currentPlayer)
        {
            bool saidUno = false;
            foreach (Player player in UnoGame.Players)
            {
                if (player.PlayerID != currentPlayer.PlayerID && player.Hand.Count == 1 && !player.UnoFlag)
                {
                    saidUno = saidUno || UnoGame.SayUnoToPlayer(player.PlayerID);
                }
            }
            return saidUno;
        }

        public void PlayTurn()
        {
            BoardIO.ClearTable();
            Player currentPlayer = UnoGame.Players[UnoGame.CurrentPlayerIndex];
            UnoGame.StartTurn();
            if (currentPlayer.Name == "COM")
            {
                PlayCOMPlayerTurn(currentPlayer);
            }
            else
            {
                //BoardIO.PrintPlayerHand(currentPlayer);
                //BoardIO.PrintTopCard(UnoGame.DiscardPile.Last());
                //BoardIO.PrintCurrentPlayer(currentPlayer);
                var playerInfo = UnoGame.Players.Select(player => (player.Name, player.Hand.Count)).ToList();
                
                while (UnoGame.gameState != GameState.TurnEnded && UnoGame.gameState != GameState.GameFinished)
                {
                    BoardIO.DisplayTable(playerInfo, UnoGame.DiscardPile.Last(), currentPlayer.Hand);
                    string option = BoardIO.GetPlayOption();
                    switch (option)
                    {
                        case "P":
                            if (currentPlayer.Played)
                            {
                                BoardIO.PrintAlreadyPlayed();
                                break;
                            }
                            int cardOption = int.Parse(BoardIO.GetCardToPlay());
                            bool validPlay = UnoGame.PlayCard(cardOption);
                            if (!validPlay)
                            {
                                BoardIO.PrintInvalidPlay();
                            }
                            break;
                        case "D":
                            if(currentPlayer.CanEndTurn)
                            {
                                BoardIO.PrintInvalidDraw();
                                break;
                            }
                            UnoGame.DrawCard();
                            break;
                        case "U":
                            bool saidUno = UnoGame.SayUNO();
                            if (!saidUno)
                            {
                                BoardIO.PrintInvalidUNO();
                            }
                            BoardIO.DisplayUNO();
                            break;
                        case "A":
                            if (SayUnoToAll(currentPlayer))
                            {
                                BoardIO.PrintUNOToAll();
                            }
                            else
                            {
                                BoardIO.PrintNoUNOToSay();
                            }
                            break;
                        case "E":
                            if (!currentPlayer.CanEndTurn)
                            {
                                BoardIO.PrintInvalidEndTurn();
                                break;
                            }
                            UnoGame.EndTurn();
                            break;
                        default:
                            BoardIO.PrintInvalidMenuOption();
                            break;
                    }
                }
     
            }
        }

        public void StartGame()
        {
            //initialize the game
            //List<string> playerNames = BoardIO.GetPlayerNames();
            BoardIO.WelcomePage();
            BoardIO.FlashingScreen();

            List<string> playerNames = new List<string> { "Player1", "COM" };
            UnoGame.InitializeGame(playerNames);

            //play the game
            while (UnoGame.gameState != GameState.GameFinished)
            {
                List<(string Name, int Count)> playerInfo = UnoGame.Players.Select(player => (player.Name, player.Hand.Count)).ToList();
                Card topCard = UnoGame.DiscardPile.Last();
                List<Card> playerHand = UnoGame.Players[UnoGame.CurrentPlayerIndex].Hand;
                BoardIO.DisplayTable(playerInfo, topCard, playerHand);
                PlayTurn();
            }
            BoardIO.AnnounceWinner(UnoGame.Players[UnoGame.CurrentPlayerIndex].Name);
        }
    }
}
