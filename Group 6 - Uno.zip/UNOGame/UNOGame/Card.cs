﻿namespace UNOGame
{
    public abstract class Card
    {
        public char Color;
        public Guid Id;

        public abstract List<string> ToStrings(int width, int height);

        public abstract bool isValid(Card topCard);
    }
}