﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UNOGame
{
    public class NumberCard : Card
    {
        public int Number { get; private set; }

        public NumberCard(int number, char color)
        {
            Id = Guid.NewGuid();
            Number = number;
            Color = color;
        }

        public override bool isValid(Card topCard)
        {
            if (topCard is NumberCard topNumberCard)
            {
                return topNumberCard.Number == Number || topNumberCard.Color == Color;
            }
            return false;
        }

        public override List<string> ToStrings(int width, int height)
        {
            char h = '_';
            string v = "|";
            string n = Number.ToString();

            List<string> rows = new();

            string topBorder = " " + new string(h, width);
            rows.Add(topBorder); // -1th row

            string topRow = v + n + new string(' ', width - n.Length) + v; // 0th row
            rows.Add(topRow);

            string otherRows = v + new string(' ', width) + v; // 1th through {height-2}th rows, except {height/2}th row
            for (int i = 1; i < height - 1; i++)
            {
                rows.Add(otherRows);
            }

            rows[1 + height / 2] = v + new string(' ', width / 2 - 1) + n + " " + new string(' ', width / 2 - 1) + v; // +1 to skip the top border; {height/2}th row

            string bottomRow = v + new string(h, width - n.Length) + n + v; // {height-1}th row
            rows.Add(bottomRow);

            return rows;
        }
    }
}
