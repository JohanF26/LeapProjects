﻿using System.Diagnostics;
using System.Drawing;
using System.Runtime.ExceptionServices;

namespace UNOGame
{
    class BoardView
    {
        /// <summary>
        /// Default width and height for displaying a card
        /// </summary>
        public static int DEFAULT_CARD_DISPLAY_WIDTH = 6;
        public static int DEFAULT_CARD_DISPLAY_HEIGHT = 5;
        /// <summary>
        /// Display a single card in the console
        /// Cards are printed vertically
        /// </summary>
        /// <param name="card"></param>
        public void Display(Card card)
        {
            int width = DEFAULT_CARD_DISPLAY_WIDTH;
            int height = DEFAULT_CARD_DISPLAY_HEIGHT;
            //Console.OutputEncoding = System.Text.Encoding.UTF8;
            //Console.WriteLine(String.Join("\n", ToStrings(width, height)));

            Console.ForegroundColor = GetConsoleColor(card.Color);
            foreach (var line in card.ToStrings(DEFAULT_CARD_DISPLAY_WIDTH, DEFAULT_CARD_DISPLAY_HEIGHT))
            {
                Console.WriteLine(line);
            }
            Console.ResetColor();
        }

        public void ClearTable()
        {
            Console.Clear();
        }

        public void DisplayTable(List<(string name, int count)> playerInfo,
            Card topCard, List<Card> playerHand)
        {
            //Console.Clear();
            Console.WriteLine("Current Table");

            //if (topCard is NumberCard)
            //{
            //    SetConsoleColor(topCard.Color);
            //    Console.WriteLine($"Top of Deck: [{((NumberCard)topCard).Number}]");
            //}
            //else
            //{
            //    Console.WriteLine($"TopCard: {topCard.Color}");
            //}
            //Console.ResetColor(); // Reset to default color
            //Console.WriteLine("------------------------------");

            foreach (var info in playerInfo)
            {
                if(info.name == "COM")
                {
                    Console.WriteLine($"Player: {info.name}  cards: {info.count}");
                    for (int i = 0; i < info.count; i++)
                    {
                        Console.Write("[] ");
                    }
                    Console.WriteLine();
                }

                //foreach (var card in playerHand)
                //    if (card is NumberCard)
                //    {
                //        SetConsoleColor(card.Color);
                //        Console.Write($"[{((NumberCard)card).Number}]  ");
                //        Console.ResetColor(); // Reset to default colors            
                //    }
                //Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine();
            Display(topCard);
            Console.WriteLine();
            Console.WriteLine();
            DisplayCardsHorizontally(playerHand, DEFAULT_CARD_DISPLAY_WIDTH, DEFAULT_CARD_DISPLAY_HEIGHT);

            Console.WriteLine("------------------------------");

        }

        /// <summary>
        /// Display a list of cards in the console horizontally
        /// </summary>
        /// <param name="cards"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public void DisplayCardsHorizontally(List<Card> cards, int width, int height)
        {
            var firstCard = cards[0];
            var firstCardId = firstCard.Id;

            List<List<string>> cardStrings = new List<List<string>>();
            foreach (var card in cards)
            {
                cardStrings.Add(card.ToStrings(width, height));
            }
            int maxRows = cardStrings.Max(cs => cs.Count);

            for (int row = 0; row < maxRows; row++)
            {
                foreach (Card card in cards)
                {
                    var cardString = card.ToStrings(width, height);
                    Debug.WriteLine(cardString);
                    if (cardString != null && row < cardString.Count)
                    {
                        Console.ForegroundColor = GetConsoleColor(card.Color);
                        //***This is where I made a lot of the changes to align the top row header of each card
                        //***The first card aligns properly, but the rest of the cards are off by one space
                        //***I added a space to the topRow headeer before all the cards that come after the first card
                        //***Also, some adjustments might need to be made in NumberCard.cs ToStrings method to improve the implementation
                        if (row == 0 && card.Id != firstCardId)
                        {
                            Console.Write(" " + cardString[row] + "  "); // Add space between cards

                        }
                        else
                        {
                            Console.Write(cardString[row] + "  "); // Add space between cards
                        }
                    }
                    else
                    {
                        Console.Write(new string(' ', width)); // Add space if the card doesn't have this row
                    }
                    Console.ResetColor();
                }
                Console.WriteLine();
            }
        }

        //internal void DisplayTable(List<(string Name, int Count)> playerInfo, Card card, List<Card> hand)
        //{
        //    Console.WriteLine("Table");
        //}

        public string GetCardToPlay()
        {
            Console.Write("Enter the index of the card you want to play (0-indexed): ");
            string? cardOption = Console.ReadLine();
            return cardOption ?? string.Empty;
        }

        public string GetPlayOption()
        {
            Console.Write("Enter 'P' to play a card,\n'D' to draw a card,\n'U' to say UNO for yourself,\n'A' to say UNO to other players,\nor 'E' to end your turn: ");
            string? option = Console.ReadLine();
            return option ?? string.Empty;
        }

        internal void PrintInvalidDraw()
        {
            Console.WriteLine("You can't draw a card right now.");
        }

        internal void PrintInvalidEndTurn()
        {
            Console.WriteLine("You must play or draw a card before you can end your turn.");
        }

        internal void PrintInvalidMenuOption()
        {
            Console.WriteLine("Invalid menu option. Please try again.");
        }

        internal void PrintInvalidPlay()
        {
            Console.WriteLine("You can't play that card right now.");
        }

        internal void PrintInvalidUNO()
        {
            Console.WriteLine("You can't say UNO right now.");
        }

        internal void PrintAlreadyPlayed()
        {
            Console.WriteLine("You already played a card this turn.");
        }

        /// <summary>
        /// Gets the console color based on the card color
        /// </summary>
        /// <param name="color"></param>
        /// <returns></returns>
        private ConsoleColor GetConsoleColor(char color)
        {
            return color switch
            {
                'r' => ConsoleColor.Red,
                'g' => ConsoleColor.Green,
                'b' => ConsoleColor.Blue,
                'y' => ConsoleColor.Yellow,
                _ => ConsoleColor.White
            };
        }

        public void SetConsoleColor(char color)
        {
            switch (color)
            {
                case 'r':
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case 'b':
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case 'g':
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case 'y':
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }
        }

        internal void PrintUNOToAll()
        {
            Console.WriteLine("UNO!\nPlayers with just 1 card have to draw 2.");
        }

        internal void PrintNoUNOToSay()
        {
            Console.WriteLine("UNO!\nBut no players had just 1 card.");
        }

        public void WelcomePage()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("************************************");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("*                                  *");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("*      Welcome to the UNO          *");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("*          Card Game!              *");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("*                                  *");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("************************************");
            Console.ResetColor();
            Thread.Sleep(5000);
        }
        public void FlashingScreen()
        {

            // Change the background color to red
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to blue
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to yellow
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to red
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();
            Thread.Sleep(500); // Wait for 500 milliseconds

            // Change the background color to blue
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Thread.Sleep(300); // Wait for 500 milliseconds
            Console.Clear();
        }

        internal void DisplayUNO()
        {
            Console.Clear();
            Console.WriteLine("UUUUUUUU     UUUUUUUUNNNNNNNN        NNNNNNNN     OOOOOOOOO     \r\nU::::::U     U::::::UN:::::::N       N::::::N   OO:::::::::OO   \r\nU::::::U     U::::::UN::::::::N      N::::::N OO:::::::::::::OO \r\nUU:::::U     U:::::UUN:::::::::N     N::::::NO:::::::OOO:::::::O\r\n U:::::U     U:::::U N::::::::::N    N::::::NO::::::O   O::::::O\r\n U:::::D     D:::::U N:::::::::::N   N::::::NO:::::O     O:::::O\r\n U:::::D     D:::::U N:::::::N::::N  N::::::NO:::::O     O:::::O\r\n U:::::D     D:::::U N::::::N N::::N N::::::NO:::::O     O:::::O\r\n U:::::D     D:::::U N::::::N  N::::N:::::::NO:::::O     O:::::O\r\n U:::::D     D:::::U N::::::N   N:::::::::::NO:::::O     O:::::O\r\n U:::::D     D:::::U N::::::N    N::::::::::NO:::::O     O:::::O\r\n U::::::U   U::::::U N::::::N     N:::::::::NO::::::O   O::::::O\r\n U:::::::UUU:::::::U N::::::N      N::::::::NO:::::::OOO:::::::O\r\n  UU:::::::::::::UU  N::::::N       N:::::::N OO:::::::::::::OO \r\n    UU:::::::::UU    N::::::N        N::::::N   OO:::::::::OO   \r\n      UUUUUUUUU      NNNNNNNN         NNNNNNN     OOOOOOOOO     ");
            Thread.Sleep(3000);
            Console.Clear();
            Console.WriteLine();
        }

        internal void AnnounceWinner(string name)
        {
            Console.WriteLine(name + " wins!");
        }
    }
}