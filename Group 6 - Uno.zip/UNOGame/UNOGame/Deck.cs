﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace UNOGame
{
    public class Deck
    {
        private static int MaxSuiteIterations = 9;
        public static List<Card> cards = new List<Card>();
        public List<Card> Cards { get { return cards; } }

        public Deck()
        {
            InitializeDeck();
        }

        public static void InitializeDeck()
        {   //These methods are static because an instance of Deck should not create a new deck,
            //it should use the same deck for all instances.
            CreateRedCards();
            CreateBlueCards();
            CreateGreenCards();
            CreateYellowCards();
        }

        public static void CreateRedCards()
        {
            cards.Add(new NumberCard(0, 'r'));

            for (int i = 1; i <= MaxSuiteIterations; i++)
            {
                cards.Add(new NumberCard(i, 'r'));
                cards.Add(new NumberCard(i, 'r'));
            }
        }
        public static void CreateBlueCards()
        {
            cards.Add(new NumberCard(0, 'b'));

            for (int i = 1; i <= MaxSuiteIterations; i++)
            {
                cards.Add(new NumberCard(i, 'b'));
                cards.Add(new NumberCard(i, 'b'));
            }
        }

        public static void CreateGreenCards()
        {
            cards.Add(new NumberCard(0, 'g'));

            for (int i = 1; i <= MaxSuiteIterations; i++)
            {
                cards.Add(new NumberCard(i, 'g'));
                cards.Add(new NumberCard(i, 'g'));
            }
        }

        public static void CreateYellowCards()
        {
            cards.Add(new NumberCard(0, 'y'));

            for (int i = 1; i <= MaxSuiteIterations; i++)
            {
                cards.Add(new NumberCard(i, 'y'));
                cards.Add(new NumberCard(i, 'y'));
            }
        }

        #region Instance Methods

        /// <summary>
        /// Shuffles the deck.
        /// </summary>
        public void Shuffle()
        {
            Random random = new Random();
            int n = cards.Count;
            while (n > 1)
            {
                n--;
                int k = random.Next(n + 1);
                Card value = cards[k];
                cards[k] = cards[n];
                cards[n] = value;
            }
        }

        /// <summary>
        /// Shuffles the deck with the discard pile.
        /// </summary>
        /// <param name="discardPile"></param>
        public void Shuffle(List<Card> discardPile)
        {
            Random random = new Random();
            int n = discardPile.Count;
            HashSet<Guid> cardIds = new HashSet<Guid>(cards.Select(card => card.Id));
            while (n > 1)
            {
                n--;
                int k = random.Next(n + 1);
                Card value = discardPile[k];
                discardPile[k] = discardPile[n];
                discardPile[n] = value;

                // Check if the card is not in the deck by checking the card id
                bool containsId = cardIds.Contains(value.Id);
                if (!containsId)
                {
                    //If card is not in the deck, add it to the deck
                    cards.Add(value);
                    //Add the card id to the HashSet so it is not added again
                    cardIds.Add(value.Id);
                }
            }

        }

        /// <summary>
        /// Draws a specified number of cards from the deck.
        /// </summary>
        /// <param name="num">The number of cards to draw.</param>
        /// <returns>A list of drawn cards.</returns>
        /// <exception cref="InvalidOperationException">Thrown when not enough cards in the deck to draw the specified number of cards.</exception>
        public List<Card> Draw(int num)
        {
            if (cards.Count < num)
            {
                throw new InvalidOperationException($"Not enough cards in the deck to draw {num} cards.");
            }
            var drawnCards = new List<Card>();
           
            for (int i = 0; i < num; i++)
            {
                drawnCards.Add(cards.Last());
                cards.RemoveAt(cards.Count - 1);

            }
            
            return drawnCards;
        }

        /// <summary>
        /// Draws a single card from the deck.
        /// </summary>
        /// <returns>The drawn card.</returns>
        /// <exception cref="InvalidOperationException">Thrown when there are no cards in the deck to draw.</exception>
        public Card Draw()
        {
            if (!cards.Any())
            {
                throw new InvalidOperationException($"No cards in the deck to draw.");
            }

            var drawnCard = cards.Last();
            cards.RemoveAt(cards.Count - 1);
            return drawnCard;
        }

        #endregion Instance Methods
    }
}