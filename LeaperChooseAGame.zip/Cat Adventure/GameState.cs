﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat_Adventure
{
    public enum GameState
    {
        WaitingToStart,
        GameStarted,
        GameOver,
        WaitingForPlayerInput
    }
}
