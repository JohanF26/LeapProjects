# Cat Adventure
Hello Cats! Welcome to the Cat Adventure! This is a game where you can play as a cat and explore the world! 
You can also play as a dog, but that's not as fun. This game is still in development, so there are a lot of bugs.
If you find any bugs, please report them in the comments. Thanks!

## Team
Christina Sherman
Christine Joo
Brandi Ude
Dennie Chan

We Love Cats!-BU
Cats are cool!-CJ