﻿namespace Cat_Adventure
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            GameManager gameManager = new GameManager();
            gameManager.Run();
        }
    }
}
