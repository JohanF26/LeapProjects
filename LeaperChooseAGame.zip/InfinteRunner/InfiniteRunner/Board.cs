﻿using InfiniteRunner.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace InfiniteRunner
{
    public class Board
    {
        // speed the board moves: times the deque/enque(update) is called per second
        double speed;
        double speedMultiplier = 30f;
        double lastQueueUpdate = 0f;
        int height = 20;
        int groundHeight = 0;
        int screenWidth = 120;
        int endBuffer = 10;
        int startBuffer = 12;
        Tuple<int, int> playerStartPosition;
        public Queue<string[]> playArea = new Queue<string[]>();
        public Player player;
        public Obstacle obstacle;
        private int obstaclesJumped;
        private int nthObstacleSpeedIncrease = 2;

        public Board(String theme)
        {
            player = ThemeFactory.GetTheme($"{theme}").player();
            obstacle = ThemeFactory.GetTheme($"{theme}").obstacle();
            playerStartPosition = new Tuple<int, int>(height - groundHeight, startBuffer);
            obstacle.obstaclePosition = screenWidth - obstacle.obstacleWidth;
            speed = 1f / speedMultiplier;
            // DHVV temp code that fills board with 0-9
            for (int i = 0; i <= screenWidth; i++)
            {
                playArea.Enqueue(getSlice(i));
            }
        }

        // returns an array string filled with 'i'
        public string[] getSlice(int i)
        {
            string[] myArray = new string[height];
            Array.Fill(myArray, " ");
            //Array.Fill(myArray, ((char)i).ToString());
            myArray[myArray.Length - 1] = "_";
            return myArray;
        }

        // Method gets called externally every fram, receives elapsed time to see if queue should be updated.
        public void update(double elapsedTime)
        {
            if (elapsedTime - lastQueueUpdate > speed)
            {
                updateQueue();
                obstacle.obstaclePosition--;
                //if obstacle hits end of screen, reset to end and speed up
                if(obstacle.obstaclePosition <= 0)
                {
                    obstacle.obstaclePosition = screenWidth - obstacle.obstacleWidth;
                    obstaclesJumped++;
                    speedMultiplier += 2f;
                    speed = 1f / speedMultiplier;
                    if(obstaclesJumped % nthObstacleSpeedIncrease == 0)
                    {
                        speedMultiplier += 2f;
                        speed = 1f / speedMultiplier;
                    }
                }

                if (player.IsJumping)
                {
                    player.Jump(elapsedTime - lastQueueUpdate);
                }
                else if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo keyInfo = Console.ReadKey(true);

                    if (keyInfo.Key == ConsoleKey.UpArrow)
                    {
                        //If player is jumping already, don't do anything
                        if (!player.IsJumping)
                        {
                            player.IsJumping = true;
                        }
                    }
                }
                lastQueueUpdate = elapsedTime;
            }
            if(obstacle.obstaclePosition > startBuffer && obstacle.obstaclePosition < startBuffer + player.Size.Item1)
            {
                obstacle.CheckCollision(player.YPosition, elapsedTime);
            }
        }

        // DHVV moves first array in queue to the end. Will need to be updated to add theme
        private void updateQueue()
        {
            string[] first = playArea.Dequeue();
            playArea.Enqueue(first);
        }

        // Flips board on its side to display it left to right. 
        public string getDisplay()
        {
            List<string[]> tempList = playArea.ToList();
            string[] display = new string[height];
            for (int i = 0; i < height; i++)
            {
                for(int j = 0; j < screenWidth; j++)
                {
                    display[i] += tempList[j][i];
                }
                display[i] += "\n";
            }
            //insert player in board
            for (int i = 0; i < player.Size.Item2; i++)
            {
                string original = display[i + height - groundHeight - player.Size.Item2 - (int)player.YPosition - 1];
                //DHVV Extract string being replaced by player, if it containt obstacle character: Game over or life lost
                display[i + height - groundHeight - player.Size.Item2 - (int)player.YPosition - 1] = original.Substring(0, startBuffer) + player.Display[i] + original.Substring(startBuffer + player.Size.Item1);
            }
            //insert obstacle
            for (int i = 0; i < obstacle.obstacleHeight; i++)
            {
                string original = display[i + height - groundHeight - obstacle.obstacleHeight - 1];
                display[i + height - groundHeight - obstacle.obstacleHeight - 1] = original.Substring(0, obstacle.obstaclePosition) + obstacle.displayString[i] + original.Substring(obstacle.obstaclePosition + obstacle.obstacleWidth);
            }

            return String.Join("", display);
        }
    }
}
