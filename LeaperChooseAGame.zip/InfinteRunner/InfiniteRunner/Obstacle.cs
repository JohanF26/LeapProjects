﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace InfiniteRunner
{
    public class Obstacle
    {
        public int obstacleWidth;
        public int obstacleHeight;
        static int obstacleSpeed = 2000; // Milliseconds between each movement
        static int screenWidth = 40;
        public static int playerPosition = 2;
        public int obstaclePosition = 0; // Initial position of the obstacle
        public string[] displayString;

        private Tuple<int, int> _size;
        private string[] _display;
        public Obstacle(String[] display, Tuple<int, int> size)
        {
            displayString = display;
            obstacleWidth = size.Item1;
            obstacleHeight = size.Item2;
        }

        public void CheckCollision(double playerJumpHeight, double deltaTime)
        {
            if (playerJumpHeight < obstacleHeight)
            {
                string gameOverTxt = "Game Over!!! Collision with obstacle.";
                Console.Clear();
                Console.WriteLine(new string('\n', 10));
                Console.SetCursorPosition((Console.WindowWidth - gameOverTxt.Length) / 2, Console.CursorTop);
                Console.WriteLine($"{gameOverTxt} \n");
                Console.WriteLine("Game Over! Collision with obstacle.");
                GameOver();
                ScoreBoard score = new ScoreBoard();
                score.showScore(deltaTime);

            }
        }

        void GameOver()
        {
            string restartTxt = "Press Space to play again or Escape to quit ";
            Console.SetCursorPosition((Console.WindowWidth - restartTxt.Length) / 2, Console.CursorTop);
            Console.WriteLine($"{restartTxt}");
            ConsoleKeyInfo userInput = Console.ReadKey(true);
            if (userInput.Key == ConsoleKey.Spacebar)
            {
                ResetGame();
            }
            else
            {
                Environment.Exit(0);
            }
        }

        public void ResetGame()
        {
            playerPosition = 2;
            obstaclePosition = 0;
            //score =0;  
            
            //environment.exit(0);

        }
    }
}
