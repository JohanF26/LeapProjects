﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace InfiniteRunner
{
    public class ScoreBoard
    {

        /// <summary>
        ///ScoreBoard will calculate and display score with user name
        /// </summary>
        DateTime endTime = DateTime.Now;
        public double gameScore = 0;
        public string? playerName;
        public double scoreCalculator(double deltaTime)
        {
            gameScore = deltaTime * 100;
            return gameScore;
        }

        public void showScore(double deltaTime)
        {
            Console.WriteLine("Please enter your name:");
            playerName = Console.ReadLine();
            gameScore = scoreCalculator(deltaTime);
            Console.WriteLine("***********************************************");
            Console.WriteLine("Player Name\t\tGame Score");
            Console.WriteLine($"{playerName}\t\t\t{gameScore}");
            Console.WriteLine("***********************************************");
            Console.ReadLine();
        }
    }
}
