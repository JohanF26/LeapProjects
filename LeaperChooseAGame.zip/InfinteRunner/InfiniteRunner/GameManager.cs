﻿using System;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Collections.Generic;
using InfiniteRunner;

public class GameManager
{
    Board myBoard;
    public void StartGame()
    {
        double frameCapCounter = 1000.0 / 240.0;
        DateTime lastTime = DateTime.Now;
        DateTime elapsedTime = DateTime.Now;

        InitGame();

        //while gamestate?
        while (true)
        {
            // Update game state
            myBoard.update((DateTime.Now - elapsedTime).TotalSeconds);

            // Draw game state// Gets the display veresion of the board(queue)
            Console.WriteLine(myBoard.getDisplay());

            // Wait for next frame
            System.Threading.Thread.Sleep((int)frameCapCounter);

            Console.Clear();
        }
    }

    public void InitGame()
    {
        Console.Clear();
        Console.WriteLine("Welcome to Infinite Runner!");
        Console.WriteLine("Please choose a theme: ");
        Console.WriteLine("Type 1 for a rabbit theme, 2 for a dinosaur theme");

        var action = Console.ReadLine();

        switch (action)
        {
            case "1":
                myBoard = new Board("rabbit");
                break;
            case "2":
                myBoard = new Board("dinosaur");
                break;
        }
    }
}
