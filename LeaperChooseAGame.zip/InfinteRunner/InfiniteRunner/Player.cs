﻿using InfiniteRunner.Interfaces;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfiniteRunner
{
    public class Player
    {
        private string _name;
        private string _displayString;
        private string[] _display;
        private double _yPosition = 0;
        //jump variables
        private bool _isJumping = false;
        private double _gravity = 5;
        private double _jumpHeight = 5;
        double _timeInAir; //Math.Sqrt((2 * _jumpHeight) / _gravity);
        double _jumpVelocity; //_gravity * _timeInAir;
        private double _initialVelocity;
        private double _timeToApex;
        private double _timeToGround;
        private double _jumpTime = 0;

        //size of display string Width, Height
        private Tuple<int, int> _size;

        // DHVV we may want to pass a theme enum in the constructor ???
        public Player(String[] display, Tuple<int,int> size)
    {
            _display = display;
            _size = size;
            _name = string.Empty;
            //initialize jump variables
            _timeInAir = Math.Sqrt((2 * _jumpHeight) / _gravity);
            _jumpVelocity = _gravity * _timeInAir;
            _initialVelocity = Math.Sqrt(2 * _gravity * _jumpHeight);
            _timeToApex = _initialVelocity / _gravity;
            _timeToGround = Math.Sqrt((2 * _jumpHeight) / _gravity) + _timeToApex;
        }
        public string Name { get { return _name; } }

        public string[] Display { get { return _display; } }

        public Tuple<int, int> Size { get { return _size; } }

        //public int YPosition { get => _yPosition; }
        public double YPosition { get { return _yPosition; } set { _yPosition = value; } }

        public bool IsJumping { get { return _isJumping; } set { _isJumping = value; } }

        public void Jump(double frameTime)
        {
            if (_yPosition == 0)
            {
                _jumpTime = 0.0;
            }
            
            //this needs to be called every jump, not within jump TODODODDODO
            if (_jumpTime < _timeToGround)
            {
                YPosition = _jumpHeight + _initialVelocity * _jumpTime - 0.5 * _gravity * _jumpTime * _jumpTime;
                _jumpTime += frameTime;
            }
            else
            {
                _isJumping = false;
                YPosition = 0;
            }

        }
    }
}
