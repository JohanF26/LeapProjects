﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InfiniteRunner.Interfaces;

namespace InfiniteRunner
{
    internal class DinosaurTheme: ITheme
    {
        public static Tuple<int, int> playerSize;
        public static Tuple<int, int> obstacleSize;
        public static string[] playerString;
        public static string[] obstacleString;

        static DinosaurTheme()
        {
            playerSize = new Tuple<int, int>(18, 6);
            playerString = ["               __ ","              / _)","     _.----._/ /  ","    /         /   "," __/ (  | (  |    ","/__.-'|_|--|_|    "];
            obstacleSize = new Tuple<int, int>(11, 5);
            obstacleString = ["_   |~  _ ", "[_]--'--[_]", "|'|\"\"`\"\"|'|", "| | /^\\ | |", "|_|_|I|_|_|"]; 
        }

        Player dinosaurPlayer = new Player(playerString, playerSize); 
        Obstacle castleObstacle = new Obstacle(obstacleString, obstacleSize);

        public Player player()
        {
            return dinosaurPlayer;
        }

        public Obstacle obstacle()
        {
            return castleObstacle;
        }
    }
}
