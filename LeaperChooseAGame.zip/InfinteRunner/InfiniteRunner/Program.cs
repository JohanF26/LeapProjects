﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfiniteRunner
{
  
    internal class Program
    {
        static void Main(string[] args)
        {
            var gm = new GameManager();
            gm.StartGame();
        }
    }
}
