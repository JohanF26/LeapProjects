﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InfiniteRunner.Interfaces;

namespace InfiniteRunner
{
    internal class RabbitTheme : ITheme
    {

        public static Tuple<int, int> playerSize;
        public static Tuple<int, int> obstacleSize;
        public static string[] playerString;
        public static string[] obstacleString;

        static RabbitTheme()
        {
            playerSize = new Tuple<int, int>(5, 4);
            playerString = [ "  // ", " ('> ", " /rr ", "*\\))_" ];
            obstacleSize = new Tuple<int, int>(6, 4);
            obstacleString = [ "  __  ", " /  \\ ", "|    |", " \\__/ " ];
        }

        Player rabbitPlayer = new Player(playerString, playerSize);
        Obstacle eggObstacle = new Obstacle(obstacleString, obstacleSize);

        public Player player()
        {
            Console.Read();
            return rabbitPlayer;
        }

        public Obstacle obstacle()
        {
            return eggObstacle;
        }
    }
}
