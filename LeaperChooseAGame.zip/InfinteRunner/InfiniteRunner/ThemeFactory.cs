﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InfiniteRunner.Interfaces;

namespace InfiniteRunner
{
    internal class ThemeFactory
    {
        public static ITheme GetTheme(string themeName)
        {
            ITheme theme = null;

            if (themeName == "rabbit") 
            { 
                theme = new RabbitTheme();
            } else
            {
                theme = new DinosaurTheme();
            }
            return theme;
        }
    }
}
