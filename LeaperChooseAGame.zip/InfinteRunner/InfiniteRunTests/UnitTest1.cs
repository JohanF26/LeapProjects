using InfiniteRunner;

namespace InfiniteRunTests
{
    [TestClass]
    public class UnitTest1
    {
        
        private readonly Obstacle obstacle;
        public UnitTest1()
        { 
            obstacle = new Obstacle(["  // ", " ('> ", " /rr ", "*\\))_"], new Tuple<int, int>(5, 4));
        }

        [TestMethod]
        public void ResetPass()
        {
            obstacle.ResetGame();
            Assert.AreEqual(obstacle.obstaclePosition, 0);
            Assert.AreEqual(Obstacle.playerPosition, 2);
        }
        [TestMethod]
        public void ResetFail()
        {
            obstacle.ResetGame();
            Assert.AreNotEqual(obstacle.obstaclePosition, 1);
            Assert.AreNotEqual(Obstacle.playerPosition, 0);
        }


    }
}