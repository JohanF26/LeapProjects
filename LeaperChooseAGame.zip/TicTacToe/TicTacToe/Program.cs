﻿using System;

namespace TicTacToe
{
    class Program
    {
        static void Main()
        {
            var gm = new GameManager();
            gm.StartGame();
        }
    }
}