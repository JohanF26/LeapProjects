﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicTacToe.Interfaces;

namespace TicTacToe
{
    public class GameManager
    {
        public static char[] board = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        public bool XorO = true;

        string userName1;
        string opponent;

        /// <summary>
        /// Input Provider
        /// </summary>
        private IInputProvider inputProvider;

        /// <summary>
        /// Output Provider
        /// </summary>
        private IOutputProvider outputProvider;

        public GameManager() : this(new ConsoleInputProvider(), new ConsoleOutputProvider())
        {

        } //look into more

        public GameManager(IInputProvider inputProvider, IOutputProvider outputProvider)
        {

            this.inputProvider = inputProvider;
            this.outputProvider = outputProvider;
        }

        internal void StartGame()
        {
            InitGame();
        }
        /// <summary>
        /// Displays Board and calls PlayerTurn and CheckBoard
        /// </summary>
        private void InitGame()
        {
            StartingGamePrompts();
            DisplayBoard();
            while (true)
            {
                PlayerTurn();
                CheckBoard();
            }
        }

        /// <summary>
        /// Sets turn variable to X or O and asks the player to enter a number between 1 and 9, and calls the update board function
        /// </summary>
        private void PlayerTurn()
        {
            char turn = 'X';

            if (!XorO)
            {
                turn = 'O';
            }

            outputProvider.WriteLine("Enter the number of the field where you want to place your " + turn);
            string input = inputProvider.Read();
            int x;

            if (!int.TryParse(input, out x) || x < 1 || x > 9)
            {
                outputProvider.WriteLine("Invalid input. Please enter a number between 1 and 9.");
                return;
            }

            UpdateBoard(x);
        }

        /// <summary>
        /// Draws the board
        /// </summary>
        internal void DisplayBoard()
        {
            outputProvider.WriteLine(" " + board[0] + " | " + board[1] + " | " + board[2]);
            outputProvider.WriteLine("---+---+---");
            outputProvider.WriteLine(" " + board[3] + " | " + board[4] + " | " + board[5]);
            outputProvider.WriteLine("---+---+---");
            outputProvider.WriteLine(" " + board[6] + " | " + board[7] + " | " + board[8]);

        }


        /// <summary>
        /// Update the board with the player's move and displays it.
        /// </summary>
        public void UpdateBoard(int x)
        {

            if (XorO)
            {
                board[x - 1] = 'X';
                XorO = false;
            }
            else
            {
                board[x - 1] = 'O';
                XorO = true;
            }
            DisplayBoard();
        }
        /// <summary>
        /// Checks for game completion and displays message and prompts user to exit. If game is not complete, it displays a message and game continues
        /// </summary>
        private void CheckBoard()
        {
            bool win = false;
            char winner = ' ';

            // check rows
            for (int i = 0; i < 9; i += 3)
            {
                if (board[i] == board[i + 1] && board[i + 1] == board[i + 2] && board[i] != ' ')
                {
                    win = true;
                    winner = board[i];
                }
            }

            // check columns
            for (int i = 0; i < 3; i++)
            {
                if (board[i] == board[i + 3] && board[i + 3] == board[i + 6])
                {
                    win = true;
                    winner = board[i];
                }
            }

            // check diagonals
            if (board[0] == board[4] && board[4] == board[8])
            {
                win = true;
                winner = board[0];
            }
            else if (board[2] == board[4] && board[4] == board[6])
            {
                win = true;
                winner = board[2];
            }

            // display results
            if (win)
            {
                outputProvider.WriteLine("Winner Winner Friend Chicken Dinner!" + winner + " wins!");
                outputProvider.WriteLine("Thank you Come again!");
                outputProvider.WriteLine("Press any key to exit...");
                Console.ReadKey();
                Environment.Exit(0);
            }
            else
            {
                outputProvider.WriteLine("Game still in progress.");
            }
        }
        public void StartingGamePrompts()
        {
            outputProvider.WriteLine("Welcome to Tic Tac Toe!!!");
            outputProvider.WriteLine("What is your name? ");
            userName1 = "" + inputProvider.Read();
            outputProvider.WriteLine("Lets get started " + userName1);
            outputProvider.WriteLine("Who do you want to play againt? ");
            outputProvider.Write("Computer, C? Yourself, Y? Another User, U?: ");
            opponent = inputProvider.Read().ToLower();
            void userOpponent()
            {
                if (opponent == "c")
                {
                    outputProvider.WriteLine($"Your opponent is the computer");
                }
                else if (opponent == "y")
                {
                    outputProvider.WriteLine("You opponent is yourself");
                }
                else if (opponent == "u")
                {
                    outputProvider.WriteLine("Your oppenent is another user");
                }
                else
                {
                    outputProvider.WriteLine($"Hey {userName1}, the input '{opponent}' is not a vaild input.");
                    outputProvider.WriteLine("Who do you want to play againt? ");
                    outputProvider.Write("Press 'c' for computer. Press 'y' for yourself. Or press 'u' for another user.");
                    opponent = inputProvider.Read().ToLower();
                    userOpponent();
                }
            }
            userOpponent();
            outputProvider.WriteLine("May the odds be in your favor!");
        }
    }
}


