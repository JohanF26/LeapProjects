﻿

namespace TicTacToe.Interfaces
{
    /// <summary>
    /// Represents something that provides outputs
    /// </summary>
    public interface IOutputProvider
    {
        /// <summary>
        /// Write output on current line
        /// </summary>
        /// <param name="output"></param>
        void Write(string output);

       /// <summary>
       ///  Write the output on the current line
       /// </summary>
       /// <param name="output"></param>
        void WriteLine(string output);

        /// <summary>
        /// Write an empty new line
        /// </summary> 
        void WriteLine();


    }
}
