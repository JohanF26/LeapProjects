﻿

namespace TicTacToe.Interfaces
{
    /// <summary>
    /// The IInputProvider interface, represents something that provides inputs
    /// </summary>
    public interface IInputProvider
    {
        /// <summary>
        /// Used to read the inputs 
        /// </summary>
        /// <returns>user Input</returns>
        string Read();
    }
}
