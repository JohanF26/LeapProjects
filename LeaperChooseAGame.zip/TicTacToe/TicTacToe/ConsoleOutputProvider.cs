﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicTacToe.Interfaces;

namespace TicTacToe
{
    class ConsoleOutputProvider : IOutputProvider
    {
        /// <summary>
        /// prints output
        /// </summary>
        /// <param name="output"></param>
        public void Write(string output)
        {
            Console.Write(output);
        }
        /// <summary>
        /// Output to console
        /// </summary>
        /// <param name="output"></param>
        public void WriteLine(string output)
        {
            Console.WriteLine(output);
        }


        public void WriteLine()
        {
            Console.WriteLine();
        }
    }
}
