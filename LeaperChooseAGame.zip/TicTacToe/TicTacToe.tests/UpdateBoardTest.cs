namespace TicTacToe
{
    [TestClass]
    public class UpdateBoardTest
    {
        [TestMethod]
        public void UTest_001()
        {
            //Arrange - initialize GameManager 
            GameManager gm = new GameManager();

            //Act - call UpdateBoard method of GameManager- pass in a mock user input of 1
            
            gm.UpdateBoard(1); // mocking user input

            //Assert - check if result is as expected
            Assert.AreEqual(GameManager.board[0],'X');

        }
    }
}


