﻿using System;
using System.Collections.Generic;

namespace SnakeGame
{
    public class Game
    {
        //SCORE temporarily set to 0
        private int currScore = 0;
        static int topScore = 0;
        private string playerName;
        bool state = true;
        //create static instance of game view
        private GameView gameView = new GameView();
        // create instances of Snake and Food
        private Snake snake = new Snake();
        private Food food = new Food();

        public Tile[,] tileArray = new Tile[GameView.ScreenWidth, GameView.ScreenHeight];

        public char[] DirectionChars = { '^', 'v', '<', '>', };
        Direction? direction =null;

        TimeSpan sleep = TimeSpan.FromMilliseconds(200);

        public void Start()
        {
            if (playerName == null)
            {
            playerName = gameView.DisplayBanner();
            }
            
            int X = snake.XCoordinate;
            int Y = snake.YCoordinate;

            gameView.Display(playerName, currScore, topScore);

            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.SetCursorPosition(X, Y);
            Console.Write('^');
            food.Spawn(tileArray);
            Console.SetCursorPosition(food.XCoordinate, food.YCoordinate);
            Console.Write(food.FoodSymbol);

            tileArray[X, Y] = Tile.Snake;
            tileArray[food.XCoordinate, food.YCoordinate] = Tile.Food;

            while (!direction.HasValue)
            {
                GetDirection();
            }

            while (state)
            {
            gameView.Display(playerName, currScore, topScore);
                // Snake starts to move
                Move();
            }
        }

        public void EndGame()
        {
            Console.Clear();
            Array.Clear(tileArray, 0, tileArray.Length);
            snake.Restart();
            
            state = gameView.GameOverBanner(currScore, topScore);

            if (currScore > topScore)
            {
                topScore = currScore;
            }
            currScore = 0;
            if (state)
            {
                Start();
            }


        }

        public bool CollideIntoWall(int x, int y)
        {

            if (x <= GameView.HorizontalIndentation || x >= GameView.HorizontalIndentation + GameView.MapWidth || y <= GameView.VerticalIndentation || y >= GameView.VerticalIndentation + GameView.MapHeight)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Cannibalise(int x, int y)
        {
            if (tileArray[x, y] == Tile.Snake)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void GetDirection()
        // takes direction from arrow keys
        {
            switch (Console.ReadKey(true).Key)
            {
                case ConsoleKey.UpArrow: direction = Direction.Up; break;
                case ConsoleKey.DownArrow: direction = Direction.Down; break;
                case ConsoleKey.LeftArrow: direction = Direction.Left; break;
                case ConsoleKey.RightArrow: direction = Direction.Right; break;
            }
        }
        public void Move()
        {
            snake.ChangeDirection(direction);
            int X = snake.XCoordinate;
            int Y = snake.YCoordinate;

            // Randomly pick snake colors for a rainbow "animation" effect
            Console.SetCursorPosition(X, Y);
            Random random = new Random();
            ConsoleColor color = (ConsoleColor)random.Next(Enum.GetValues(typeof(ConsoleColor)).Length);
            Console.ForegroundColor = color;
            Console.Write(DirectionChars[(int)direction]);

            // Check if the snake collides with the wall or itself
            if (CollideIntoWall(X, Y) || Cannibalise(X, Y))
            {
                EndGame();
            }
            snake.Grow();
            if (tileArray[X, Y] is Tile.Food)
            {
                Console.SetCursorPosition(X, Y);
                
                food.Spawn(tileArray);
                food.Clear();
                tileArray[food.XCoordinate,food.YCoordinate] = Tile.Food;
                currScore++;
                System.Threading.Thread.Sleep(1000);
            }
            else
            {
                (int c, int d) = snake.Body.Dequeue();  // Have to figure out how to use snake as queue
                tileArray[c, d] = Tile.Open;
                Console.SetCursorPosition(c, d);
                Console.Write(' ');
            }
            Console.SetCursorPosition(X, Y);
            Console.Write(DirectionChars[(int)direction]);
            tileArray[X, Y] = Tile.Snake;
            if (Console.KeyAvailable)
            {
                GetDirection();
            }
            Console.SetCursorPosition(food.XCoordinate, food.YCoordinate);
            Console.Write(food.FoodSymbol);
            System.Threading.Thread.Sleep(sleep);
        }
    }
}