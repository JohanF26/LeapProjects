﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace SnakeGame
{
    public class LeaderBoard
    {

        private string fileName = Path.Combine(Directory.GetCurrentDirectory(), "leaderboard.txt");
       // StreamReader reader = new StreamReader(Path.Combine(Directory.GetCurrentDirectory(), "leaderboard.txt"));
        private string fileNames;
        private int playerScore;
        private string playerName;
        public Dictionary<string,int> leaderBoardEntry { get; set; }
        

        public LeaderBoard(string playerName, int playerScore) 
        {

            // Load Scores when we instantiate object in Game Over Screen
            try
            {
                leaderBoardEntry = new Dictionary<string, int>();
                this.playerName = playerName;
                this.playerScore = playerScore;

            }
            catch(Exception e)
            {
                Console.WriteLine(e);

            }

        }


        public void addScores()
        {
            leaderBoardEntry.Add(playerName, playerScore);
            List<string> playerInfo = new List<string>(); 

            foreach(var entry in leaderBoardEntry)
            {
                playerInfo.Add($"Name: {entry.Key}, Score: {entry.Value}");
            }


            ///var playerLine = leaderBoardEntry.Select(playerEntry => $"Name: {playerEntry.Key}, Score: {playerEntry.Value}").ToList();
            try
            {
                string varFile = string.Join(Environment.NewLine, playerInfo);
                File.AppendAllLines(fileName, playerInfo);
               // string content = reader.ReadLine();
               // reader.Close();

            }
            catch (Exception e) {
                Console.Error.Write(e);
            }
        }

        public Dictionary<string, int> loadScores()
        {
           // string content = fileName;
            Dictionary<string, int> scores = new Dictionary<string, int>();

            foreach(var entry in leaderBoardEntry)
            {
                scores.Add(entry.Key, entry.Value);
            }


            return scores;
        }

        public void addEntryManually(string playerName, int playerScore)
        {
            leaderBoardEntry.Add(playerName, playerScore);
        }


    }
}
