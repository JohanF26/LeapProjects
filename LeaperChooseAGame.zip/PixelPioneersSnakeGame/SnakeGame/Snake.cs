﻿using System;
using System.Collections.Generic;

namespace SnakeGame
{
    public class Snake
    {
        public Queue<(int, int)> Body { get; set; }
        private int X;
        private int Y;
        public int XCoordinate { get { return X; } }
        public int YCoordinate { get { return Y; } }

        public Snake()
        {
            Body = new Queue<(int, int)>();
            Random random = new Random();
            X = random.Next(GameView.HorizontalIndentation + 1, GameView.HorizontalIndentation + GameView.MapWidth);
            Y = random.Next(GameView.VerticalIndentation + 1, GameView.VerticalIndentation + GameView.MapHeight);
            var randomTuple = (X, Y);
            Body.Enqueue(randomTuple);
        }

        // We might not need ChangeDirection, since we can have GetDirection instead
        public void ChangeDirection(Direction? direction)
        {
            if (direction != null)
            {
                switch (direction)
                {
                    case Direction.Left: X = X - 1; break;
                    case Direction.Right: X = X + 1; break;
                    case Direction.Up: Y = Y - 1; break;
                    case Direction.Down: Y = Y + 1; break;
                }
            }
            else
            {
                throw new ArgumentNullException("Direction cannot be null");
            }
        }

        /// <summary>
        /// Deletes the whole snake body
        /// </summary>
        public void Restart()
        {
            Body.Clear();
            Random random = new Random();
            X = random.Next(GameView.HorizontalIndentation + 1, GameView.HorizontalIndentation + GameView.MapWidth);
            Y = random.Next(GameView.VerticalIndentation + 1, GameView.VerticalIndentation + GameView.MapHeight);
            var randomTuple = (X, Y);
            Body.Enqueue(randomTuple);
        }

        public void Grow()
        {
            Body.Enqueue((X, Y));
        }
        //body shrink
        public (int, int) Shrink()
        {
            (int x, int y) = Body.Dequeue();
            return (x, y);
        }
    }
}