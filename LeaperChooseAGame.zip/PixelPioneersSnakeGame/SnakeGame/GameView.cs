﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using static System.Console;

namespace SnakeGame
{
    internal class GameView
    {
        public const int MapWidth = 90;
        public const int MapHeight = 20;

        public const int ScreenWidth = MapWidth * 2;
        public const int ScreenHeight = MapHeight + 10;

        private const ConsoleColor BorderColor = ConsoleColor.Gray;
        private const ConsoleColor BodyColor = ConsoleColor.Cyan;
        private const ConsoleColor HeadColor = ConsoleColor.DarkBlue;

        //set the horizontal indentation
        public const int HorizontalIndentation = 5;
        public const int VerticalIndentation = 5;

        string playerName;
        int currScore;

        private LeaderBoard leaderboard;
        Dictionary<string, int> scores;


        //char[] DirectionChars = { '^', 'v', '<', '>', };
        /// <summary>
        ///  To Retrieve Map information from Outside the Class
        /// </summary>
        /// <returns></returns>


        internal void Display(string playerName, int currScore, int topScore)
        {

            this.playerName = playerName;
            this.currScore = currScore;

            // Set the window size 
            SetWindowSize(ScreenWidth, ScreenHeight);
            CursorVisible = false;

            //write the name of the player and the score
            ForegroundColor = ConsoleColor.Cyan;
            SetCursorPosition(2, 0);
            WriteLine("Player: " + playerName);
            SetCursorPosition(2, 1);
            WriteLine("Top Score: " + topScore);
            SetCursorPosition(2, 2);
            WriteLine("Current Score: " + currScore);

            // Draw top border
            SetCursorPosition(HorizontalIndentation, VerticalIndentation);
            ForegroundColor = BorderColor;
            Write(new string('█', MapWidth + 2));

            // Draw bottom border
            SetCursorPosition(HorizontalIndentation, MapHeight + VerticalIndentation);
            Write(new string('█', MapWidth + 2));

            // Draw left and right borders
            for (var i = 0; i < MapHeight; i++)
            {
                SetCursorPosition(HorizontalIndentation, i + VerticalIndentation);
                Write('█');
                SetCursorPosition(HorizontalIndentation + MapWidth+1, i +VerticalIndentation);
                Write('█');
            }

            // Display Snake
            //SetCursorPosition(snake.Body.Peek().Item1, snake.Body.Peek().Item2);
            //Write(DirectionChars[snake.snakeDirection]);
            //ReadKey(true);
            //Clear();
            //WriteLine("\x1b[3J");
        }
        internal string DisplayBanner()
        {
            Clear();
            ForegroundColor = ConsoleColor.Green;
            SetCursorPosition(10, 5);
            WriteLine("███████╗███╗   ██╗ █████╗ ██╗  ██╗███████╗     ██████╗  █████╗ ███╗   ███╗███████╗"); SetCursorPosition(10, 6);
            WriteLine("██╔════╝████╗  ██║██╔══██╗██║ ██╔╝██╔════╝    ██╔════╝ ██╔══██╗████╗ ████║██╔════╝"); SetCursorPosition(10, 7);
            WriteLine("███████╗██╔██╗ ██║███████║█████╔╝ █████╗      ██║  ███╗███████║██╔████╔██║█████╗  "); SetCursorPosition(10, 8);
            WriteLine("╚════██║██║╚██╗██║██╔══██║██╔═██╗ ██╔══╝      ██║   ██║██╔══██║██║╚██╔╝██║██╔══╝  "); SetCursorPosition(10, 9);
            WriteLine("███████║██║ ╚████║██║  ██║██║  ██╗███████╗    ╚██████╔╝██║  ██║██║ ╚═╝ ██║███████╗"); SetCursorPosition(10, 10);
            WriteLine("╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝     ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝");

            ForegroundColor = ConsoleColor.Yellow;
            SetCursorPosition(10, 12);
            WriteLine("Use the arrow keys to move the snake. The snake will grow when it eats the food. ");
            SetCursorPosition(10, 13);
            WriteLine("The game will end when the snake collides with the wall or itself.");
            SetCursorPosition(10, 15);
            ForegroundColor = ConsoleColor.DarkGreen;
            Write("To start the game please enter your name:  ");
            string playerName = ReadLine();
            //SetCursorPosition(10, 18);
            //WriteLine("Press any key to start the game...");
            //SetCursorPosition(10, 14);
            //ReadKey(true);
            Clear();
            return playerName;
        }

        internal bool GameOverBanner(int currScore, int topScore)
        {
            ForegroundColor = ConsoleColor.Red;
            SetCursorPosition(10, 5);
            WriteLine(" ██████╗  █████╗ ███╗   ███╗███████╗     ██████╗ ██╗   ██╗███████╗██████╗ "); SetCursorPosition(10, 6);
            WriteLine("██╔════╝ ██╔══██╗████╗ ████║██╔════╝    ██╔═══██╗██║   ██║██╔════╝██╔══██╗"); SetCursorPosition(10, 7);
            WriteLine("██║  ███╗███████║██╔████╔██║█████╗      ██║   ██║██║   ██║█████╗  ██████╔╝"); SetCursorPosition(10, 8);
            WriteLine("██║   ██║██╔══██║██║╚██╔╝██║██╔══╝      ██║   ██║╚██╗ ██╔╝██╔══╝  ██╔══██╗"); SetCursorPosition(10, 9);
            WriteLine("╚██████╔╝██║  ██║██║ ╚═╝ ██║███████╗    ╚██████╔╝ ╚████╔╝ ███████╗██║  ██║"); SetCursorPosition(10, 10);
            WriteLine(" ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝     ╚═════╝   ╚═══╝  ╚══════╝╚═╝  ╚═╝");

            ForegroundColor = ConsoleColor.Yellow;
            SetCursorPosition(10, 12);
            WriteLine("Top Score: " + topScore);
            SetCursorPosition(10, 14);
            WriteLine("Current Score: " + currScore);
            //enter 1 to restart the game; any key to exit
            SetCursorPosition(10, 16);
            ForegroundColor = ConsoleColor.DarkGreen;
            SetCursorPosition(15, 18);
            leaderboard = new LeaderBoard(playerName, currScore);
            leaderboard.addEntryManually("Alexis", 20);
            leaderboard.addEntryManually("Nina", 14);
            leaderboard.addEntryManually("Rawand", 7);
            leaderboard.addScores();
            scores = leaderboard.loadScores();
            List<String> gameoverScores = new List<string>();
        
      
            gameoverScores = GetScores(scores);

            WriteLine("Top 3 Leaderboard: ");
            WriteLine("-------------------------------");

            foreach(String gameoverScore in gameoverScores)
            {
                WriteLine(gameoverScore);
            }
            WriteLine("--------------------------------");

            SetCursorPosition(20, 25);

            Write("Enter 1 to restart the game or press Enter to exit the game:  ");
            string choice = ReadLine();
            Clear();
            if (choice == "1")
            {
                return true;
            }
            return false;
        }


        public List<String> GetScores(Dictionary<string, int> dictionary)
        {
            var topThree = dictionary.OrderByDescending(pair => pair.Value)
                .Take(3)
                .ToDictionary(pair => pair.Key, pair => pair.Value);

            List<String> scores = new List<String>();

            foreach(var entry in topThree)
            {
                scores.Add($"{entry.Key} , {entry.Value}");

            }

            return scores;
        }

    }
}