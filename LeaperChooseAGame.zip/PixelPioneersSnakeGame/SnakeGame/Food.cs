﻿using System;
using static System.Console;

namespace SnakeGame
{
    internal class Food
    {
        static string[] foods = new string[] {
            "\U0001F34E", // apple
            "\U0001F354", // burger
            "\U0001F355", // pizza
            "\U0001F355", // meat on bone
            "\U0001F363", // sushi
            "\U0001F365", // fish cake with swirl
            "\U0001F36B", // chocolate
            "\U0001F966", // broccoli
            "\U0001F95E", // pancakes
            "\U0001F369", // donut  
        };
        private int X;
        private int Y;
        public string FoodSymbol;

        public int XCoordinate { get { return X; } }
        public int YCoordinate { get { return Y; } }

        public Food(int x = 0, int y = 0)
        {
            X = x;
            Y = y;
        }

        public void Spawn(Tile[,] tileArray)
        {
            Random random = new Random();
            // Assigns a coordinate x that is chosen at random in the confines of the game map
            int x = random.Next(GameView.HorizontalIndentation + 1, GameView.HorizontalIndentation + GameView.MapWidth);

            // Assigns a coordinate y that is chosen at random in the confines of the game map
            int y = random.Next(GameView.VerticalIndentation + 1, GameView.VerticalIndentation + GameView.MapHeight);

            while (tileArray[x, y] != Tile.Open)
            {
                // Assigns a coordinate x, y that is chosen at random in the confines of the game map
                x = random.Next(GameView.HorizontalIndentation + 1, GameView.HorizontalIndentation+ GameView.MapWidth);
                y = random.Next(GameView.VerticalIndentation + 1, GameView.VerticalIndentation + GameView.MapHeight);
            }

            X = x;
            Y = y;
            // Picks a random food symbol from the array of food symbols
            int index = random.Next(0, Food.foods.Length);
            FoodSymbol = Food.foods[index];
        }

        public void Clear()
        {
            SetCursorPosition(X, Y);
            Write(' ');
        }
    }
}