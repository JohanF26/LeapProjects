﻿namespace SnakeGame
{
    public enum Tile
    {
        Open = 0,
        Snake = 1,
        Food = 2,
    }
}
