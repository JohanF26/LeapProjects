﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeApp.Models
{
    public enum Speed
    {
        Slow = 1,
        Medium = 2,
        Fast = 3
    }
}
