namespace SnakeApp.Tests
{
    [TestClass]
    public class GameControllerTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}