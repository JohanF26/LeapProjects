namespace SnakeApp.Tests
{
    [TestClass]
    public class ConsoleViewTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}