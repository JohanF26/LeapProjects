namespace SnakeApp.Tests
{
    [TestClass]
    public class GameClassTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}