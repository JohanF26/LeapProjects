namespace SnakeApp.Tests
{
    [TestClass]
    public class SnakeClassTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}