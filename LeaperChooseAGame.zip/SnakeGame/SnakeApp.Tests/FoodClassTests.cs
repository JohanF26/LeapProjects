namespace SnakeApp.Tests
{
    [TestClass]
    public class FoodClassTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}