﻿using System;

namespace MatchingGame
{
    public enum GameMode
    {

        Easy = 2,
        Medium = 4,
        Hard = 6,
    }
}
