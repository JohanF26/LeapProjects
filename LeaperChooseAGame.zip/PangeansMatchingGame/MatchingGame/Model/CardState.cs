﻿namespace MatchingGame.Model
{
    public enum CardState
    {
        Guessed,
        NotGuessed,
        Guessing
    }
}

