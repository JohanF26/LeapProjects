﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace BlackJack_VS_proj
{
    public class Player
    {
        internal string name;
        internal bool isBust;
        internal int playerMoney;
        internal int handRunningTotal;
        internal Hand playerHand;



        public Player(string playerName)
        {
            name = playerName;
            isBust = false;
            playerMoney = 100;
            playerHand = new Hand();
        }

        public int CalculatePlayerHandTotal()
        {
            int aceCount = 0;
            int playerRunningTotal = 0;

            foreach (Card card in playerHand.Cards)
            {
                if (card.GetFacePointVal() == 11)
                {
                    aceCount++;
                }
            }
            if (aceCount > 0)
            {
                foreach (Card card in playerHand.Cards)
                {
                    playerRunningTotal += card.GetFacePointVal();
                }
                if (playerRunningTotal > 21)
                {
                    while (playerRunningTotal > 21 && aceCount > 0)
                    {
                        playerRunningTotal -= 10;
                        aceCount--;
                    }
                }
                if (playerRunningTotal > 21)
                {
                    isBust = true;
                }
                return playerRunningTotal;
            }
            else
            {
                foreach (Card card in playerHand.Cards)
                {
                    playerRunningTotal += card.GetFacePointVal();
                }
                if (playerRunningTotal > 21)
                {
                    isBust = true;
                }
                return playerRunningTotal;
            }
        }
    }
}