﻿using System.Text;

namespace BlackJack_VS_proj;

public enum SuitType
{
    CLUBS = 0,
    DIAMONDS = 1,
    HEARTS = 2,
    SPADES = 3
}

public class Card
{
    public static string[] VALID_FACE_VALUES = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    public static int DEFAULT_CARD_DISPLAY_WIDTH = 6;
    public static int DEFAULT_CARD_DISPLAY_HEIGHT = 5;
    internal SuitType Suit { get; }
    internal string FaceVal { get; }
    public Card(SuitType suit, string faceVal)
    {
        Suit = suit;
        FaceVal = faceVal;
    }

    public int GetFacePointVal()
    {
        int val;
        switch (FaceVal)
        {
            case "J":
            case "Q":
            case "K": val = 10; break;
            case "A": val = 11; break;
            default: val = int.Parse(FaceVal); break;
        }
        return val;
    }

    public void Display()
    {
        int width = DEFAULT_CARD_DISPLAY_WIDTH;
        int height = DEFAULT_CARD_DISPLAY_HEIGHT;
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.WriteLine(String.Join("\n", ToStrings(width, height)));
    }

    // width should be even and height should be odd so that the 2-char-wide suitString is centered
    // witdh and height should be at least 3 and 4 respectively
    // width is the number of '_' in the top border
    // height is the number of '|' in ea. of the left and right border
    public virtual List<string> ToStrings(int width, int height)
    {
        string h = "_";
        string v = "|";
        string f = FaceVal;

        List<string> rows = new();

        string topBorder = " " + h.Multiply(width);
        rows.Add(topBorder); // -1th row

        string topRow = v + f + " ".Multiply(width - f.Length) + v; // 0th row
        rows.Add(topRow);

        string otherRows = v + " ".Multiply(width) + v; // 1th through {height-2}th rows, except {height/2}th row
        for (int i = 1; i < height - 1; i++)
        {
            rows.Add(otherRows);
        }
        string suitString = Suit.ToString1();
        rows[1 + height / 2] = v + " ".Multiply(width / 2 - 1) + suitString + " ".Multiply(width / 2 - 1) + v; // +1 to skip the top border; {height/2}th row

        string bottomRow = v + "_".Multiply(width-f.Length) + f + v; // {height-1}th row
        rows.Add(bottomRow);

        return rows;
    }
}

