﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Text;

namespace BlackJack_VS_proj
{
    public class Deck
    {
        private Stack<Card> stack;
        public int CardCount { get { return stack.Count(); } }
        public Deck()
        {
            stack = new Stack<Card>();
            SuitType[] suits = (SuitType[])Enum.GetValues(typeof(SuitType));
            
            foreach (SuitType suit in suits)
            {
                foreach (string value in Card.VALID_FACE_VALUES)
                {
                    stack.Push(new Card(suit, value));
                }
            }
            Shuffle();
        }

        public void Shuffle()
        {
            var rng = new Random();
            var values = stack.ToArray();
            stack.Clear();

            for (int n = values.Length - 1; n > 0; n--)
            {
                int k = rng.Next(n + 1);
                (values[k], values[n]) = (values[n], values[k]);
            }

            foreach (var value in values)
            {
                stack.Push(value);
            }
        }
        public Card GetTopCard()
        {
            if (stack.Count > 0)
            {
                return stack.Pop();
            }
            else
            {
                throw new InvalidOperationException("Deck is empty");
            }
        }
    }
}