﻿using BlackJack_VS_proj;

Console.WriteLine("Play BlackJack!");
var game = new GameManger();
game.Play();
