﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJack_VS_proj
{
    public class Dealer : Player
    {
        internal Deck gameDeck;
        public Dealer(string dealerName) : base(dealerName)
        {
            isBust = false;
            playerMoney = 100;
            gameDeck = new Deck();
        }

        public void InitialDeal(List<Player> players)
        {
            // Dealer deals 1 upside down card and one regular card to themselves
            Card temp = gameDeck.GetTopCard();
            playerHand.AddCard(new UpsideDownCard(temp.Suit, temp.FaceVal));
            PlayerDeal(this);


            for (int i = 0; i < 2; i++)
            {
                foreach (Player player in players)
                {
                    PlayerDeal(player);
                }
            }
        }

        public void PlayerDeal(Player player)
        {
            player.playerHand.AddCard(gameDeck.GetTopCard());
            player.handRunningTotal = player.CalculatePlayerHandTotal();
        }
    }
}