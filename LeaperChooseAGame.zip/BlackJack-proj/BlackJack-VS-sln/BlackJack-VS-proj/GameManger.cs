﻿using BlackJack_VS_proj;
using System.Data;
using System.Numerics;

namespace BlackJack_VS_proj
{
    public class GameManger
    {
        public static int MIN_NUM_PLAYERS = 1;
        public static int MAX_NUM_PLAYERS = 5;
        Deck deck = new Deck();
        List<Player> players = new List<Player>();
        int numPlayers;
        int currPlayerIdx = 0;
        Dealer dealer = new Dealer("Dealer");
        List<string> playerResults = new();

        #region Game Methods

        public string AskHitOrStay()
        {
            string reply;
            do
            {
                Console.Write("HIT OR STAY?     ");
                reply = Console.ReadLine().ToLower().Trim();
            } while (reply != "hit" && reply != "stay");
            return reply;
        }

        public void AskForPlayerNames()
        {
            string reply;
            do
            {
                Console.Write($"How many players (between {MIN_NUM_PLAYERS} and {MAX_NUM_PLAYERS} players)?   ");
                reply = Console.ReadLine().Trim();
            }
            while (!int.TryParse(reply, out numPlayers) || numPlayers < MIN_NUM_PLAYERS || numPlayers > MAX_NUM_PLAYERS);


            string name;
            for (int i = 1; i <= numPlayers; i++)
            {
                Console.WriteLine();
                do
                {
                    Console.Write($"What is player {i}'s name? (must be non-empty)    ");
                    name = Console.ReadLine().Trim();
                }
                while (String.IsNullOrEmpty(name));
                players.Add(new Player(name));
                playerResults.Add("?");
            }
        }

        public void DisplayPlayerTable()
        {
            string format = "{0,-6}{1,-10}{2,-15}{3,-15}{4,-10}";
            string header = String.Format(format, "", "Player", "Name", "Hand Total", "Winner (player or dealer?)");
            Console.WriteLine(header);
            Player player;
            string playerIndicator = "";
            string totalDescriptive;
            for (int i = 0; i < numPlayers; i++)
            {
                player = players[i];
                if (i == currPlayerIdx)
                {
                    playerIndicator = "---->";
                }
                else
                {
                    playerIndicator = "";
                }
                totalDescriptive = $"{player.handRunningTotal}";
                if (player.isBust)
                {
                    totalDescriptive += " (Busted!)";
                } else if (i < currPlayerIdx)
                {
                    if (player.handRunningTotal == 21)
                    {
                        totalDescriptive += ("BlackJack!!!");
                    }
                    else if (i != numPlayers)
                    {
                        totalDescriptive += " (Staying)";
                    }
                }
                Console.WriteLine(String.Format(format, playerIndicator, i + 1, player.name, totalDescriptive, playerResults[i]));
            }
        }

        public void Play()
        {
            AskForPlayerNames();
            Player player;

            dealer.InitialDeal(players); // TODO: should deal for every player / DONE?
            for (currPlayerIdx = 0; currPlayerIdx < numPlayers; currPlayerIdx++)
            {
                player = players[currPlayerIdx];

                Console.WriteLine($"Player #{currPlayerIdx+1}: {player.name}'s Turn");
                
                while (true)
                {
                    player.handRunningTotal = player.CalculatePlayerHandTotal();
                    PrintGameStatus(dealer, player); // TOOD: only print the hand of one player at a time // DONE?
                    if (player.handRunningTotal == 21)
                    {
                        Console.WriteLine();
                        Console.WriteLine("BlackJack! You have 21!");
                        Console.WriteLine();
                        break;
                    }
                    string userSelection = AskHitOrStay();
                    if (userSelection == "stay")
                    {
                        break;
                    }
                    else if (userSelection == "hit")
                    {
                        dealer.PlayerDeal(player);
                        player.handRunningTotal = player.CalculatePlayerHandTotal();
                        if (player.isBust)
                        {
                            Console.WriteLine("You busted! Dealer wins.");
                            break;
                        }
                    }
                    Console.WriteLine();
                }
            }
            DealerTurn();
            DetermineWinner(); // TODO: determine winner for every player
            Console.Clear();
            DisplayPlayerTable();
            PrintGameStatus(dealer, null, true);
            Console.ReadKey();
            Console.WriteLine();
        }

        public void DealerTurn()
        {
            dealer.handRunningTotal = dealer.CalculatePlayerHandTotal();
            dealer.playerHand.Cards[0] = new Card(dealer.playerHand.Cards[0].Suit, dealer.playerHand.Cards[0].FaceVal);
            DisplayPlayerTable();
            PrintGameStatus(dealer, null, true);
            //dealer.playerHand.Display();
            while (dealer.handRunningTotal < 17)
            {
                Thread.Sleep(750);
                dealer.PlayerDeal(dealer);
                dealer.handRunningTotal = dealer.CalculatePlayerHandTotal();
                DisplayPlayerTable();
                PrintGameStatus(dealer, null, true);
            }
        }

        public void DetermineWinner()
        {
            for (int i = 0; i < numPlayers; i++)
            {
                Player player = players[i];
                if (
                    (dealer.handRunningTotal == 21 && player.handRunningTotal == 21)
                    || (dealer.isBust && player.isBust)
                    )
                {
                    playerResults[i] = "Push (tie; nobody wins)";
                }
                else if (player.isBust)
                {
                    playerResults[i] = "Dealer wins!";
                }
                else if (dealer.isBust)
                {
                    playerResults[i] = $"{player.name} wins!";
                }
                else if (dealer.handRunningTotal >= player.handRunningTotal)
                {
                    playerResults[i] = "Dealer wins!";
                }
                else
                {
                    playerResults[i] = $"{player.name} wins!";
                }
            }
        }

        public void PrintGameStatus(Dealer theDealer, Player? thePlayer, bool isDealersTurn = false)
        {
            Console.Clear();
            DisplayPlayerTable();
            if (thePlayer is not null) {
                Console.WriteLine();
                Console.WriteLine($"{thePlayer.name}'s Hand");
                thePlayer.playerHand.Display();
                Console.WriteLine($"Your hand total is: {thePlayer.handRunningTotal}");
            }
            Console.WriteLine();
            Console.WriteLine("Dealer's Hand");
            theDealer.playerHand.Display();
            if (isDealersTurn)
            {
                Console.WriteLine($"Dealer's hand total is: {theDealer.handRunningTotal}");
            }
            Console.WriteLine();
        }

        #endregion Game Methods
    }
}