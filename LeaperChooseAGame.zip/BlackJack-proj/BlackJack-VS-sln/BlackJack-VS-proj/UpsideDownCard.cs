﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJack_VS_proj;

public class UpsideDownCard : Card
{
    public UpsideDownCard(SuitType suit, string faceVal) : base(suit, faceVal) { }

    public override List<string> ToStrings(int width, int height)
    {
        string h = "_";
        string v = "|";
        List<string> rows = new();
        rows.Add(" " + h.Multiply(width));

        string otherRows = v + " ".Multiply(width) + v;
        for (int i = 0; i < height - 1; i++)
        {
            rows.Add(otherRows);
        }
        rows.Add(v + h.Multiply(width) + v);
        return rows;
    }

}