﻿using System;
using Wordle;

public class Program
{
    static void Main(string[] args)
    {
        var game = new GameController();
        game.StartGame();
    }
}
