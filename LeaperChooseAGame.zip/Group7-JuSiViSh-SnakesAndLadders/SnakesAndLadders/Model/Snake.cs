﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.Model
{
    internal class Snake : IObstacles
    {
        private int _StartCellNumber;
        private int _EndCellNumber;
        private string _Symbol;
        private string _TypeOfObstacle;

        public Snake(int startCellNumber, int endCellNumber)
        {
            if(startCellNumber <= endCellNumber)
            {
                throw new ArgumentException("Start cell number should be greater than end cell number");
            }
            if(startCellNumber > 36 || endCellNumber > 36)
            {
                throw new ArgumentException("Start cell number and end cell number should be less than 36");
            }
            _StartCellNumber = startCellNumber;
            _EndCellNumber = endCellNumber;
            _TypeOfObstacle = "Snake";
            _Symbol = "S" + endCellNumber;
        }
        public int GetEndCellNumber() => _EndCellNumber;
        public int GetStartCellNumber() => _StartCellNumber;
        public string GetSymbol() => _Symbol;
        public string GetTypeOfObstacle() => _TypeOfObstacle;
    }
}
