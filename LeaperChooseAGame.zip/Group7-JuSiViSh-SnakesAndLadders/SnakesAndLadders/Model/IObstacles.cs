﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.Model
{
    public interface IObstacles
    {
        String GetSymbol(); //S12 , L 29
        String GetTypeOfObstacle(); //Snake , Ladder
        int GetStartCellNumber();
        int GetEndCellNumber();
    }
}
