﻿using SnakesAndLadders.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SnakesAndLadders.Constants.BasicModeGameConstants;

namespace SnakesAndLadders.Model
{
    public class Board
    {
        // Properties
        private readonly List<Cell> Cells;
        private readonly int Size = BoardSize;
        
        // Constructor
        public Board()
        {
            Cells = new List<Cell>();
            for (int i = 0; i < Size; i++)
            {
                Cell cell = new Cell();
                Cells.Add(cell);
                if(5 == i)
                {
                    AddSnake(cell, i, 1);
                }
                if(4 == i)
                {
                    AddLadder(cell, i, 9);
                }
                if (7 == i)
                {
                    AddLadder(cell, i, 20);
                }
                if (9 == i)
                {
                    AddSnake(cell, i, 3);
                }
                if (12 == i)
                {
                    AddSnake(cell, i, 1);
                }
                if (14 == i)
                {
                    AddLadder(cell, i, 22);
                }
                if (18 == i)
                {
                    AddLadder(cell, i, 31);
                }
                if (20 == i)
                {
                    AddSnake(cell, i, 9);
                }
                if (25 == i)
                {
                    AddSnake(cell, i, 2);
                }
                if (28 == i)
                {
                    AddLadder(cell, i, 35);
                }
                if (31 == i)
                {
                    AddSnake(cell, i, 7);
                }
                if (33 == i)
                {
                    AddSnake(cell, i, 30);
                }
            }
        }

        // Methods
        public Cell GetCell(int index) => Cells[index];
        public int GetSize() => Size;
        private void AddSnake(Cell cell, int startCell, int endCell)
        {
            Snake snake = new Snake(startCell, endCell);
            cell.SetObstacle(snake);
        }
        private void AddLadder(Cell cell, int startCell, int endCell)
        {
            Ladder ladder = new Ladder(startCell, endCell);
            cell.SetObstacle(ladder);
        }
    }
}
