﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.Model
{
    public class Cell
    {
        // Properties
        private readonly List<Player> Players;
        private readonly int CellNumber;
        private IObstacles? Obstacle = null;

        // Constructor
        public Cell()
        {
            Players = [];
        }

        // Methods
        public List<Player> GetPlayers() => Players;
        public void AddPlayer(Player player) => Players.Add(player);
        public void RemovePlayer(Player player) => Players.Remove(player);
        public void SetObstacle(IObstacles obstacle) => Obstacle = obstacle;
        public IObstacles? GetObstacle() => Obstacle;
    }
}
