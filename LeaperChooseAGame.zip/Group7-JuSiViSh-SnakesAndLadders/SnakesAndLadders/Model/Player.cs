﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SnakesAndLadders.Constants;
using SnakesAndLadders.Controller;

namespace SnakesAndLadders.Model
{
    public class Player
    {

        private String _name;
        private String _icon;
        private int _curPosition;
        private int _prevPosition;
        

        public String Name
        {
            get { return _name; }
            private set { _name = value; }
        }

        public String Icon
        {
            get { return _icon; }
            private set { _icon = value; }
        }

        public int CurPosition
        {
            get { return _curPosition; }
            private set { _curPosition = value; }
        }

        public int PrevPosition
        {
            get { return _prevPosition; }
            private set { _prevPosition = value; }
        }

        public Player(String name,  String icon)
        {
            this._name = name;
            this._icon = icon;
            this._curPosition = BasicModeGameConstants.startPosition;
            this._prevPosition = BasicModeGameConstants.startPosition;
        }

        public void MovePlayer(int nextPosition)
        {
            if (nextPosition < 1 || nextPosition > BasicModeGameConstants.BoardSize)
            {
                //throw exception.
                return;
            }
            this.PrevPosition = _curPosition;
            this.CurPosition = nextPosition;
        }
    }
}
