﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.Model
{
    // <summary>
    // Represents a six-sided dice.
    // </summary>
    public class Dice
    {
        private Random _random = new Random();

        public Dice()
        {

        }

        /// <summary>
        /// Method rolls a random number between 1 and 6.
        /// </summary>
        /// <returns>the rolled random number.</returns>
        public int RollRandomNumber() => _random.Next(1, 7);
        
    }


}
