﻿using SnakesAndLadders.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.View
{
    public class DisplayDice
    {
        Dice dice = new Dice();


        /// <summary>
        /// Simulates the animation of rolling the dice and clear it at the end.
        /// </summary>
        public void RollAnimation()
        {
           
            Console.WriteLine("Rolling the dice...");

            int rollCount = 6; // Number of times to roll the dice

            for (int i = 0; i < rollCount; i++)
            {
                Console.Clear();
                Console.WriteLine("Rolling the dice...");

                Console.WriteLine("===> " + dice.RollRandomNumber());
                System.Threading.Thread.Sleep(400);
            }

            Console.Clear();
        }

        /// <summary>
        /// Simulates the animation of rolling the dice by displaying dice face and clear it at the end.
        /// </summary>
        public void RollAnimationWithGraphic()
        {
            Console.WriteLine("Rolling the dice...");

            // Create an array of dice faces
            string[] diceFaces = new string[]
            {
                    " ---------\n |       |\n |   *   |\n |       |\n ---------", // Face 1
                    " ---------\n | *     |\n |       |\n |     * |\n ---------", // Face 2
                    " ---------\n | *     |\n |   *   |\n |     * |\n ---------", // Face 3
                    " ---------\n | *   * |\n |       |\n | *   * |\n ---------", // Face 4
                    " ---------\n | *   * |\n |   *   |\n | *   * |\n ---------", // Face 5
                    " ---------\n | *   * |\n | *   * |\n | *   * |\n ---------"  // Face 6
            };

            int rollCount = 6;

            for (int i = 0; i < rollCount; i++)
            {
                Console.Clear();
                Console.WriteLine("Rolling the dice...");
                Console.WriteLine(diceFaces[dice.RollRandomNumber() - 1]);
                System.Threading.Thread.Sleep(400);
            }

            Console.Clear();

        }





    }
}
