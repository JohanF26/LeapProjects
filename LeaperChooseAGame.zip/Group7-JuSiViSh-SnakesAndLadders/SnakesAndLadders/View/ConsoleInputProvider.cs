﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SnakesAndLadders.View.Interface;

namespace SnakesAndLadders.View
{
    /// <summary>
    /// Ths ConsoleInputProvider class, provides inputs from the Console
    /// </summary>
    class ConsoleInputProvider : IInputProvider
    {
        /// <summary>
        /// Read a line from the console
        /// </summary>
        /// <returns></returns>
        public string Read()
        {
            return Console.ReadLine();
        }
    }
}
