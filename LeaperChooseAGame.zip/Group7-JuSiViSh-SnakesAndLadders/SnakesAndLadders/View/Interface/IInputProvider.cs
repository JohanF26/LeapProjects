﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.View.Interface
{/// <summary>
 /// The IInputProvider interface, represents something that provides inputs
 /// </summary>
    public interface IInputProvider
    {
        /// <summary>
        /// Read the input
        /// </summary>
        /// <returns>The input</returns>
        string Read();
    }
}
