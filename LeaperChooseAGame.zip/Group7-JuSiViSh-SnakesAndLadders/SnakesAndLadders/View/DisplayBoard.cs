﻿using SnakesAndLadders.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.View
{
    public class DisplayBoard
    {
        private readonly Board Board;
        private readonly string TopLeftCorner = "\u2554";
        private readonly string Horizontal = "\u2550";
        private readonly string TopRightCorner = "\u2557";
        private readonly string Vertical = "\u2551";
        private readonly string BottomLeftCorner = "\u255A";
        private readonly string BottomRightCorner = "\u255D";
        private readonly string Space = " ";
        private readonly int CellWidth = 8;
        private readonly int CellHeight = 6;
        private readonly List<String> CellColors = new List<String> { "\x1b[36m" , 
                                                                      "\x1b[32m" ,
                                                                      "\x1b[31m" ,
                                                                      "\x1b[33m" };
        private readonly string ResetColor = "\x1b[0m";
        public DisplayBoard(Board board)
        {
            Board = board;
            Console.SetWindowSize(1024, 1024);
        }
       
        public void Display(Player p, int position)
        {
            //Implementation has to be changed.
            Display();
        }

        public void Display()
        {
            int columnNumber = 1;
            for (int i = Board.GetSize() - 1; i >= 0; i--)
            {
                int row = ((Board.GetSize() - 1) - i) / 6;
                int col;
                col = SnakingCellMath(ref columnNumber, i);

                Console.SetCursorPosition(col * CellWidth, row * CellHeight);
                Cell cell = Board.GetCell(i);
                string color = SetCellColor(i, cell);

                StringBuilder cellString = new();
                cellString.Append(color);
                cellString.Append(TopLeftCorner + Horizontal + Horizontal + Horizontal + Horizontal + Horizontal + Horizontal + TopRightCorner);
                cellString.Append(ResetColor);
                PrintAndResetCursor(1, row, col, cellString);

                cellString.Append(color);
                InsertCellNumber(i, cellString);
                cellString.Append(ResetColor);
                PrintAndResetCursor(2, row, col, cellString);

                cellString.Append(color);
                InsertObstacle(cell, cellString);
                cellString.Append(ResetColor);
                PrintAndResetCursor(3, row, col, cellString);

                cellString.Append(color);
                InsertPlayerSymbols(cell, cellString, color);
                cellString.Append(ResetColor);
                PrintAndResetCursor(4, row, col, cellString);

                cellString.Append(color);
                cellString.Append(BottomLeftCorner + Horizontal + Horizontal + Horizontal + Horizontal + Horizontal + Horizontal + BottomRightCorner);
                cellString.Append(ResetColor);
                PrintAndResetCursor(5, row, col, cellString);
            }
        }

        private static string SetCellColor(int i, Cell cell)
        {
            string color;
            if (cell.GetObstacle() == null)
            {
                color = "\x1b[40m";
            }
            else if (cell.GetObstacle().GetTypeOfObstacle() == "Ladder")
            {
                color = "\x1b[32m";
            }
            else
            {
                color = "\x1b[31m";
            }

            if (i == 0 || i == 35)
            {
                color = "\x1b[36m";
            }

            if (cell.GetPlayers().Count() != 0)
            {
                color = "\x1b[33m";
            }

            return color;
        }

        private void InsertObstacle(Cell cell, StringBuilder cellString)
        {
            if (cell.GetObstacle() == null)
            {
                cellString.Append(Vertical + Space + Space + Space + Space + Space + Space + Vertical);
            }
            else
            {
                if (cell.GetObstacle().GetSymbol().Length == 3)
                {
                    cellString.Append(Vertical + Space + cell.GetObstacle().GetSymbol() + Space + Space + Vertical);
                }
                else
                {
                    cellString.Append(Vertical + Space + Space + cell.GetObstacle().GetSymbol() + Space + Space + Vertical);
                }
            }
        }

        private int SnakingCellMath(ref int columnNumber, int i)
        {
            int col;
            if (i == 29 || i == 23 || i == 17 || i == 11 || i == 5)
            {
                columnNumber++;
            }

            if (columnNumber % 2 == 0)
            {
                col = i % 6;
            }
            else
            {
                col = ((Board.GetSize() - 1) - i) % 6;
            }

            return col;
        }

        private void InsertCellNumber(int i, StringBuilder cellString)
        {   
            if (i > 8)
            {
                cellString.Append(Vertical + Space + Space + (i + 1) + Space + Space + Vertical);
            }
            else
            {
                cellString.Append(Vertical + Space + Space + Space + (i + 1) + Space + Space + Vertical);
            }
        }

        private void InsertPlayerSymbols(Cell cell, StringBuilder cellString, string color)
        {
            if (cell.GetPlayers().Count() == 0 )
            {
                cellString.Append(Vertical + Space + Space + Space + Space + Space + Space + Vertical);
            }
            else
            {
                List<String> playerSymbols = [Space];
                foreach (Player player in cell.GetPlayers())
                {
                    playerSymbols.Add(player.Icon.ToString());
                }
                for (int x = playerSymbols.Count(); x < 6; x++)
                {
                    playerSymbols.Add(Space);
                }
                cellString.Append(Vertical + playerSymbols[0] + playerSymbols[1] + playerSymbols[2] + playerSymbols[3] + playerSymbols[4] + playerSymbols[5] + color + Vertical + ResetColor);
            }
        }

        private void PrintAndResetCursor(int i, int row, int col, StringBuilder cellString)
        {   
            //what does i represent ? 
            Console.Write(cellString);
            cellString.Clear();
            Console.SetCursorPosition(col * CellWidth, (row * CellHeight) + i);
        }


        public async void displayPlayerMovement(Player player, bool isCausedByObstacle)
        {
            int curPosition = player.CurPosition;
            int prevPosition = player.PrevPosition;

            if (isCausedByObstacle)
            {
                //When the player movement is triggered by an obstacle - ladder or a snake, player moves directly to the end of the obstacle.
                //display the board with the position of the player as the end of the obstacle.
                Display();
            } 
            else
            {
               //when the player movement is caused by rolling dice - player hops from their current position to the next one step at a time.
               //for every hop the play has to make between their cur position and next position, display the board
               for(int position = prevPosition + 1; position <= curPosition; position++)
               {
                    //display Player player in the cell "position" on the board

                    //Display(player, position);
                    await Task.Delay(4500);
                }
            }
        }
    }
}
