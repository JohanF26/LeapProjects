﻿using SnakesAndLadders.Controller;

var game = new GameController();
game.StartSnakeAndLadder();
