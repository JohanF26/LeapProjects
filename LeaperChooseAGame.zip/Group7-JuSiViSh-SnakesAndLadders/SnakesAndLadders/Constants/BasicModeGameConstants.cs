﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.Constants
{
    public static class BasicModeGameConstants
    {
        public static readonly int startPosition = 1;
        public static readonly int BoardSize = 36;
        public static readonly int BoardRows = 6;
        public static readonly int BoardColumns = 6;

        public static readonly int NumberOfPlayers = 4;

        public static readonly int NumberOfSnakes = 4;
        public static readonly int NumberOfLadders = 5;

        public static List<String> PlayerIcons = ["\x1b[36m*\x1b[0m", "\x1b[32m#\x1b[0m" , "\x1b[31m$\x1b[0m" , "\x1b[33m@\x1b[0m"];
        

        //create an Enum for game difficulty.

    }
}
