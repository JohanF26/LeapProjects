﻿using SnakesAndLadders.Constants;
using SnakesAndLadders.Model;
using SnakesAndLadders.View;
using SnakesAndLadders.View.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLadders.Controller
{
    public class GameController
    {


        /// <summary>
        /// The input provider
        /// </summary>
        private IInputProvider inputProvider;

        /// <summary>
        /// The output provider
        /// </summary>
        private IOutputProvider outputProvider;

        /// <summary>
        /// Declaring a board for Snake and Ladder
        /// </summary>
        ///       
        Board snakeAndLadderBoard;
        DisplayBoard displaySnakeAndLadderBoard;
        Dice dice;
        Player player;
        Cell cell;
        DisplayDice displayDice;

        //string playerName;
        int playerPosition = BasicModeGameConstants.startPosition;

        //ask and add number of players
        //add list of players

        List<Player> playerList = new List<Player>();
        int numberOfPlayers = 0;
        bool gameOver = false;



        public GameController() : this(new ConsoleInputProvider(), new ConsoleOutputProvider())
        {

        }

        public GameController(IInputProvider inputProvider, IOutputProvider outputProvider)
        {
            if (inputProvider == null)
                throw new ArgumentNullException(nameof(inputProvider));
            if (outputProvider == null)
                throw new ArgumentNullException(nameof(outputProvider));

            this.inputProvider = inputProvider;
            this.outputProvider = outputProvider;
        }

        public void StartSnakeAndLadder()
        {
            snakeAndLadderBoard = new Board();
            displaySnakeAndLadderBoard = new DisplayBoard(snakeAndLadderBoard);
            dice = new Dice();


            outputProvider.WriteLine("Welcome to the Snake and Ladder Game!");
            RunGameLoop();
        }

        private void ShowPlayers()
        {
            foreach (var showPlayer in playerList)
            {
                outputProvider.WriteLine($" {showPlayer.Name} is  {showPlayer.Icon}\n");

            }
        }

        private void RunGameLoop()
        {
            while (true)
            {
                outputProvider.WriteLine("\nPlease enter 'p' to play or 'q' to quit:\n");
                var playerInput = inputProvider.Read().ToLower();

                if (playerInput == "p")
                {
                    gameOver = false;
                    playerList.Clear();
                    GetNumberOfPlayers();
                    PlaySnakeAndLadder();
                }
                else if (playerInput == "q")
                {
                    outputProvider.WriteLine("Exiting the program.");
                    break;
                }
                else
                {
                    outputProvider.WriteLine("Invalid input. Please try again");
                }
            }
        }


        private void GetNumberOfPlayers()
        {
            while (true)
            {
                outputProvider.WriteLine("Please enter the number of players:");
                if (int.TryParse(Console.ReadLine(), out numberOfPlayers) && numberOfPlayers > 0 && numberOfPlayers < 5)
                {
                    break;
                }
                else
                {
                    outputProvider.WriteLine("Invalid input. Please select players between 1 to 4. Press enter to continue");
                    inputProvider.Read();
                }
            }

            for(int i = 0; i < numberOfPlayers; i++)
            {
                outputProvider.WriteLine($"Please enter the name of player {i+1} :");
                string playerName = Console.ReadLine();
                Player playerForList = new Player(playerName, BasicModeGameConstants.PlayerIcons[i]);
                playerList.Add(playerForList);
                cell = snakeAndLadderBoard.GetCell(0);
                cell.AddPlayer(playerForList);
            }
        }


        private void PlaySnakeAndLadder()
        {
            int diceValue;
            int snakeEndValue;
            int ladderEndValue;

            int milliseconds = 1000;
            int playerTurnCounter = 0;
            int exceedPosition = 0;
            displayDice = new DisplayDice();

            while (true && !gameOver)
            {
                player = playerList[playerTurnCounter%numberOfPlayers];
                if(player.CurPosition == 36 )
                {
                    playerTurnCounter++;
                    continue;
                }
                outputProvider.WriteLine($"Player {player.Name}'s turn to roll the dice.");

                while (true && !gameOver)
                {
                    outputProvider.WriteLine("Press enter to roll the dice");
                    inputProvider.Read();

                    outputProvider.WriteLine("\nRolling the Dice:\n");
                    diceValue = dice.RollRandomNumber();
                    //diceValue = 6;
                    displayDice.RollAnimationWithGraphic();// check for display of Dice

                    Thread.Sleep(milliseconds);
                    //Add animation of rolling the dice
                    outputProvider.WriteLine($"{player.Name} rolled {diceValue}");


                    Thread.Sleep(milliseconds);

                    if(player.CurPosition + diceValue > 36)
                    {

                        outputProvider.WriteLine($"{player.Name} rolled more than 36 so moving back the player\n");
                        inputProvider.Read();


                        // required position = 36 -(DiceValue -(36 - player.CurPosition))
                        var changePosition = diceValue + player.CurPosition - BasicModeGameConstants.BoardSize;
                        exceedPosition = BasicModeGameConstants.BoardSize - changePosition;

                        cell = snakeAndLadderBoard.GetCell(player.CurPosition -1);
                        cell.RemovePlayer(player);

                        player.MovePlayer(exceedPosition);
                        player.MovePlayer(exceedPosition);// want to set both current and previous positions to same value
                        cell = snakeAndLadderBoard.GetCell(player.CurPosition -1);
                        cell.AddPlayer(player);
                        Console.Clear();
                        displaySnakeAndLadderBoard.Display();
                        ShowPlayers();
                        Thread.Sleep(milliseconds);

                    }

                    else
                    {
                        player.MovePlayer(Math.Min(player.CurPosition + diceValue, BasicModeGameConstants.BoardSize));
                        playerPosition = player.PrevPosition;
                        cell = snakeAndLadderBoard.GetCell(player.PrevPosition - 1); //0

                        for (int i = playerPosition - 1; i < Math.Min(player.CurPosition, BasicModeGameConstants.BoardSize); i++)
                        {
                            cell.RemovePlayer(player);
                            cell = snakeAndLadderBoard.GetCell(i);
                            cell.AddPlayer(player);
                            Console.Clear();
                            displaySnakeAndLadderBoard.Display();
                            ShowPlayers();
                            Thread.Sleep(milliseconds);


                        }

                    }
                    
                    cell = snakeAndLadderBoard.GetCell(player.CurPosition - 1);
                    var snakeOrLadder = cell.GetObstacle();
                    if (snakeOrLadder != null)
                    {
                        if (snakeOrLadder is Snake)
                        {
                            outputProvider.WriteLine("\nYou landed on a Snake!!!!!\nPress Enter to continue:");
                            inputProvider.Read();
                            snakeEndValue = snakeOrLadder.GetEndCellNumber();
                            player.MovePlayer(snakeEndValue);
                            cell.RemovePlayer(player);
                            cell = snakeAndLadderBoard.GetCell(snakeEndValue - 1);
                            cell.AddPlayer(player);
                            Console.Clear();
                            displaySnakeAndLadderBoard.Display();
                            ShowPlayers();
                            Thread.Sleep(milliseconds);

                        }
                        else
                        {
                            outputProvider.WriteLine("\nWohoo!!!! you landed on a ladder.\nPress Enter to continue:");
                            inputProvider.Read();
                            ladderEndValue = snakeOrLadder.GetEndCellNumber();
                            player.MovePlayer(ladderEndValue);
                            cell.RemovePlayer(player);
                            cell = snakeAndLadderBoard.GetCell(ladderEndValue - 1);
                            cell.AddPlayer(player);
                            Console.Clear();
                            displaySnakeAndLadderBoard.Display();
                            ShowPlayers();

                            Thread.Sleep(milliseconds);

                        }

                    }

                    

                    if (diceValue == 6)
                    {
                        outputProvider.WriteLine($"Another chance to roll the dice as {player.Name} rolled 6.\n");
                        continue;

                    }
                    

                    if (player.CurPosition >= BasicModeGameConstants.BoardSize)
                    {
                        outputProvider.WriteLine($"{player.Name} is moved to position {BasicModeGameConstants.BoardSize}\n");
                        outputProvider.WriteLine($"{player.Name} won the game!!");
                        if (GetNumberOfRemaningPlayers() > 1)
                        {
                            playerTurnCounter++;
                            break;
                        }
                        else
                        {
                            gameOver = true;
                            break;
                        }

                    }
                    else
                    {
                        outputProvider.WriteLine($"{player.Name} is moved to position {player.CurPosition}.\n");
                        playerTurnCounter++;
                        break;

                    }

                }

            }
           
        }

        public int GetNumberOfRemaningPlayers()
        {
            int numberOfRemaningPlayers = 0;
            foreach ( Player player in playerList ) 
            {
                if(player.CurPosition < BasicModeGameConstants.BoardSize)
                {
                    numberOfRemaningPlayers++;
                }
            }
            return numberOfRemaningPlayers;
        }






    }
}


/* if (playerPosition > 36)
                     {
                         var changePosition = playerPosition - 36;
                         playerPosition = 36 - changePosition;
                     }
                     Console.Clear();
                     displaySnakeAndLadderBoard.Display();*/
