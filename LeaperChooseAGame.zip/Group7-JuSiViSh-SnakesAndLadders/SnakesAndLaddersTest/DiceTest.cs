﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using SnakesAndLadders.Model;
using NuGet.Frameworks;


namespace SnakeAndLaddersTest
{
    [TestClass]
    public class DiceTests
    {
        [TestMethod]
        public void DiceReturnsRandomBetween1And6()
        { 
            // Arrange
            Dice dice = new Dice();

            //Act
            int result = dice.RollRandomNumber();

            //Assert
          
            Assert.IsTrue(result >= 1 && result <= 6);
            Assert.AreNotEqual(0, result);

        }
        
    }
}