using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using SnakesAndLadders.Controller;

namespace SnakeAndLaddersTest
{
    [TestClass]
    public class Tests_SnakeAndLadder
    {
        [TestMethod]
        public void Test_001()
        {

            GameController gameController = new GameController();
        //    int result = gameController.ReturnSeven();
        //    Assert.AreEqual(7, result);
        }


    }
}