﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SnakesAndLadders.Model;
using SnakesAndLadders.Constants;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SnakesAndLaddersTest
{
    [TestClass]
    public class PlayerTest
    {
        [TestMethod]
        public void Test_Player_Instantiation()
        {
            Player player1 = new Player("P1", "*");
            Assert.AreEqual(player1.Name, "P1");
            Assert.AreEqual(player1.CurPosition, BasicModeGameConstants.startPosition);
            Assert.AreEqual(player1.Icon, "*");
            Assert.IsInstanceOfType(player1, typeof(Player));
        }

        [TestMethod]
        public void Test_Player_MovePlayer_Invalid_Case_1()
        {
            Player player2 = new Player("P2", "@");
            Assert.AreEqual(player2.CurPosition, BasicModeGameConstants.startPosition);
            int prevPosition = player2.CurPosition;
            player2.MovePlayer(-1);
            Assert.AreEqual(player2.CurPosition, prevPosition);

        }

        [TestMethod]
        public void Test_Player_MovePlayer_Invalid_Case_2()
        {
            Player player2 = new Player("P2", "@");
            Assert.AreEqual(player2.CurPosition, BasicModeGameConstants.startPosition);
            int prevPosition = player2.CurPosition;
            player2.MovePlayer(BasicModeGameConstants.BoardSize + 1);
            Assert.AreEqual(player2.CurPosition, prevPosition);

        }

        [TestMethod]
        public void Test_Player_MovePlayer_Valid_Case_Dice_Roll()
        {
            Player player2 = new Player("P2", "@");
            Assert.AreEqual(player2.CurPosition, BasicModeGameConstants.startPosition);
            int prevPosition = player2.CurPosition;
            player2.MovePlayer(prevPosition + 5);
            Assert.AreNotEqual(player2.CurPosition, prevPosition);
            Assert.AreEqual(player2.CurPosition, prevPosition + 5);
            
        }

        [TestMethod]
        public void Test_Player_MovePlayer_Valid_Case_MoveUp()
        {
            //Initialize
            Player player2 = new Player("P2", "@");
            Assert.AreEqual(player2.CurPosition, BasicModeGameConstants.startPosition);
            int prevPosition = player2.CurPosition;

            //Act
            player2.MovePlayer(20);

            //Asset
            Assert.AreNotEqual(player2.CurPosition, prevPosition);
            Assert.AreEqual(player2.CurPosition, 20);
        }

        [TestMethod]
        public void Test_Player_MovePlayer_Valid_Case_MoveDown()
        {
            Player player2 = new Player("P2", "@");
            Assert.AreEqual(player2.CurPosition, BasicModeGameConstants.startPosition);
            int prevPosition = player2.CurPosition;
            player2.MovePlayer(20);
            player2.MovePlayer(5);

            Assert.AreNotEqual(player2.CurPosition, prevPosition);
            Assert.AreNotEqual(player2.CurPosition, prevPosition + 20);
            Assert.AreEqual(player2.CurPosition, 5);

        }
    }
}
