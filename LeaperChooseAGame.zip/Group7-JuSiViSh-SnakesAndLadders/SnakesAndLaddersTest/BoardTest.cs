﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using SnakesAndLadders.Controller;
using SnakesAndLadders.Model;
using SnakesAndLadders.View;

namespace SnakeAndLaddersTest
{
    [TestClass]
    public class BoardTest
    {
        [TestMethod]
        public void TestBoardDisplay()
        {
            Board board = new Board();
            DisplayBoard displayBoard = new DisplayBoard(board);
            displayBoard.Display();
        }


    }
}