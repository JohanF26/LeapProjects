﻿
using System.Globalization;
using System.Runtime.InteropServices;
using LeapWoF.Interfaces;

namespace LeapWoF
{
    class Program
    {
        static void Main(string[] args)
        {
            var gm = new GameManager();
            gm.StartGame();
        }
    }
}
