﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeapWoF
{
    internal class Player
    {
        public string Name { get; private set; }
        public int TotalMoney { get; private set; }
        public int RoundMoney { get; private set; }

        public Player(string name)
        {
            Name = name;
            TotalMoney = 0;
            RoundMoney = 0;
        }

        public void WinRound()
        {
            TotalMoney += RoundMoney;
            RoundMoney = 0;
        }

        public void ClearRoundMoney()
        {
            RoundMoney = 0;
        }

        public void AddMoney(int money, int lettersGuessed)
        {
            RoundMoney += (money * lettersGuessed);
        }
    }
}
