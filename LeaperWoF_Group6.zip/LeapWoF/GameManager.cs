﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Text;
using System.Media;
using System.IO;
using LeapWoF.Interfaces;
using System.Threading;

namespace LeapWoF
{

    /// <summary>
    /// The GameManager class, handles all game logic
    /// </summary>
    public class GameManager
    {
        /// <summary>
        /// The input provider
        /// </summary>
        private IInputProvider inputProvider;

        /// <summary>
        /// The output provider
        /// </summary>
        private IOutputProvider outputProvider;

        private Puzzle puzzle;

        private List<int> Wheel;

        private List<Player> Players;

        public List<string> charGuessList = new List<string>();

        private int currentTurn;

        public GameState GameState { get; private set; }

        // Property to hold the list of puzzles
        public List<Puzzle> PuzzlesList { get; set; }

        public GameManager() : this(new ConsoleInputProvider(), new ConsoleOutputProvider())
        {

        }

        public GameManager(IInputProvider inputProvider, IOutputProvider outputProvider)
        {
            if (inputProvider == null)
                throw new ArgumentNullException(nameof(inputProvider));
            if (outputProvider == null)
                throw new ArgumentNullException(nameof(outputProvider));

            this.inputProvider = inputProvider;
            this.outputProvider = outputProvider;
            this.puzzle = new Puzzle(outputProvider);
            Wheel = new List<int> { 200, 200, 200, 200, 300, 300, 300, 400, 400, 500, 500, 1000, 0, 0, -1 };
            Players = new List<Player>();
            GameState = GameState.WaitingToStart;

            //*** Not being used, but wouldn't hurt to keep here for now?
            //PuzzlesList = new List<Puzzle>
            //{
            //    new Puzzle ("Videogames", "Renegade in Outer Space", "Star Wars Outlaws" ),
            //    new Puzzle ("Entertainment", "Rivlas DC", "Marvel" ),
            //    new Puzzle ("Movies", "The Force Awakens", "Star Wars")
            //};
        }

        public void InitPlayers()
        {
            outputProvider.WriteLine("Please enter the number of players:");
            var numPlayers = int.Parse(inputProvider.Read());
            for (int i = 0; i < numPlayers; i++)
            {
                outputProvider.WriteLine($"Please enter the name of player {i + 1}:");
                var playerName = inputProvider.Read();
                Players.Add(new Player(playerName));
            }
            currentTurn = 0;
        }

        /// <summary>
        /// Manage game according to game state
        /// </summary>
        public void StartGame()
        {
            InitGame();

            //Game loop that ends once the game state is GameOver
            while (GameState != GameState.GameOver)
            {

                PerformSingleTurn();

                if (GameState == GameState.RoundOver)  //***GameState should change to RoundOver if solved correctly.  This logic should be in a method that checks for solved
                {
                    //StartNewRound();
                    GameState = GameState.GameOver;
                    continue;
                }


            }
            var winner = Players.OrderByDescending(p => p.TotalMoney).First();
            outputProvider.WriteLine($"{winner.Name} wins with ${winner.TotalMoney}!");
            outputProvider.WriteLine("Game over");
        }

        public Puzzle ChooseCategory() //***Not being used yet, I made it so that we are only focusing on logic for one puzzle.  This can be implemented later.
        {
            Puzzle puzzle = null;
            Console.WriteLine("Select a category (1 to 3):");

            // Loop until a valid option is selected
            while (puzzle == null)
            {
                string option = inputProvider.Read(); // Get user input

                // Validate the input and assign puzzle accordingly
                switch (option)
                {
                    case "1":
                        if (PuzzlesList.Count > 0)
                            puzzle = PuzzlesList[0];
                        break;
                    case "2":
                        if (PuzzlesList.Count > 1)
                            puzzle = PuzzlesList[1];
                        break;
                    case "3":
                        if (PuzzlesList.Count > 2)
                            puzzle = PuzzlesList[2];
                        break;
                    default:
                        Console.WriteLine("Invalid option, please select between 1 to 3.");
                        break;
                }

                if (puzzle == null)
                {
                    Console.WriteLine("Please enter a valid category (1 to 3).");
                }
            }
            return puzzle;
        }

        public void StartNewRound()
        {
            // update the game state
            GameState = GameState.RoundStarted;
        }

        public void PerformSingleTurn()
        {
            DisplayPlayers();
            puzzle.DisplayPuzzle();
            puzzle.DisplayHints();
            outputProvider.WriteLine($"It's {Players[currentTurn].Name}'s turn");
            outputProvider.WriteLine("Type 1 to spin, 2 to solve, 3 to quit");
            GameState = GameState.WaitingForUserInput;

            var action = inputProvider.Read();

            switch (action)
            {
                case "1":
                    Spin();
                    break;
                case "2":
                    Solve();
                    break;
                case "3":
                    End();
                    break;
                default:
                    outputProvider.Clear();
                    outputProvider.WriteLine("Invalid option, please select between 1 to 3.");
                    break;
            }
        }

        public void DisplayPlayers()
        {
            outputProvider.WriteLine("Players:");
            foreach (var player in Players)
            {
                outputProvider.WriteLine($"{player.Name} - Round: ${player.RoundMoney} - Total: ${player.TotalMoney}");
            }
        }

        public void EndTurn()
        {
            currentTurn = (currentTurn + 1) % Players.Count;
        }


        /// <summary>
        /// Spin the wheel and do the appropriate action
        /// </summary>
        public void Spin()
        {
            outputProvider.WriteLine("Spinning the wheel...");
            var money = Wheel[new Random().Next(0, Wheel.Count)];
            if (money > 0)
            {
                outputProvider.WriteLine($"{money}!");
                GuessLetter(money);
            }
            else
            {
                if (money == -1)
                {
                    outputProvider.WriteLine("Bankrupt!");
                    Players[currentTurn].ClearRoundMoney();
                }
                else
                {
                    outputProvider.WriteLine("Lose a Turn!");
                }
                EndTurn();
            }

        }

        public void Solve()
        {
            outputProvider.Write("Please enter your solution:");
            GameState = GameState.WaitingForUserInput;
            var guess = inputProvider.Read();
            GameState = GameState.Solving;
            outputProvider.Clear();
            if (puzzle.CheckGuess(guess))
            {
                outputProvider.WriteLine($"Correct! The answer was \"{puzzle.Answer}\"\n{Players[currentTurn].Name} wins the round!");
                PlayMusic();
                Players[currentTurn].WinRound();
                GameState = GameState.RoundOver;
            }
            else
            {
                outputProvider.WriteLine("Incorrect!");
                EndTurn();
            }
        }



        public void End()
        {
            GameState = GameState.GameOver;
        }
        public void GuessLetter(int money)
        {
            outputProvider.Write("Please guess a letter: ");
            GameState = GameState.WaitingForUserInput;
            var guess = inputProvider.Read();
            GameState = GameState.GuessingLetter;
            outputProvider.Clear();
            //check guess has not been guessed before and that only one char was provided
            if (charGuessList.Contains(guess) || guess.Length > 1)
            {
                outputProvider.WriteLine("Incorrect!");
                EndTurn();
            }
            else
            {
                charGuessList.Add(guess.ToLower());
                if (puzzle.CheckLetterGuess(guess[0]))
                {
                    outputProvider.WriteLine("Correct!");
                    Players[currentTurn].AddMoney(money, puzzle.CorrectGuesses);
                }
                else
                {
                    outputProvider.WriteLine("Incorrect!");
                    EndTurn();
                }
            }
        }

        /// <summary>
        /// Optional logic to accept configuration options
        /// </summary>
        public void InitGame()
        {
            outputProvider.WriteLine("****************************");
            outputProvider.WriteLine("Leap 2025 - Group 6");
            outputProvider.WriteLine("Created by:  Johan, Calvin and Patricia");
            outputProvider.WriteLine("   ");
            outputProvider.WriteLine("Welcome to the Wheel of Fortune Game!");
            outputProvider.WriteLine("   ");


            outputProvider.WriteLine("\rGOOD LUCK!!");
            Thread.Sleep(5000);

            InitPlayers();
            StartNewRound();
        }

        public void PlayMusic(string filePath)
        {
            filePath = filePath ?? Path.Combine(Directory.GetParent(Environment.CurrentDirectory).Parent.FullName, "Audiofiles", "kayVess_Outlaws_Theme.wav");

            try
            {
                // Normalize the path
                filePath = Path.GetFullPath(filePath);
                //outputProvider.WriteLine(filePath);

                if (File.Exists(filePath))
                {
                    SoundPlayer player = new SoundPlayer(filePath);
                    player.Play();
                    Thread.Sleep(15000);
                    outputProvider.WriteLine("The force is STRONG in YOU!\n");

                }
                else
                {
                    outputProvider.WriteLine("We wanted play some music, but... just meditate for now");
                }
            }
            catch (FileNotFoundException fnfEx)
            {
                outputProvider.WriteLine($"File not found: {fnfEx.Message}");
            }
            catch (UnauthorizedAccessException uaEx)
            {
                outputProvider.WriteLine($"Access denied: {uaEx.Message}");
            }
            catch (Exception ex)
            {
                outputProvider.WriteLine($"An unexpected error occurred: {ex.Message}");
            }
        }
        public void PlayMusic()
        {
            PlayMusic(null);
        }

    }

}
