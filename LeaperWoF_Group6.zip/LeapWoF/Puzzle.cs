
using System.Security.Policy;
using System.Text;
using System;
using System.Collections.Generic;
using LeapWoF.Interfaces;

namespace LeapWoF
{
    /// <summary>
    /// This Puzzle class, details the console puzzle
    /// </summary>

    public class Puzzle
    {

        private IOutputProvider outputProvider;

        // Properties
        public string Category { get; private set; }
        public string Answer { get; private set; }
        private string Answer_lower { get; set; }
        public string Phrase { get; private set; }
        public string Puzzle_string { get; set; }
        public int CorrectGuesses { get; private set; }

        //Constructors


        // Injected Dependencies
        public Puzzle(IOutputProvider outputProvider)
        {
            if (outputProvider == null)
                throw new ArgumentNullException(nameof(outputProvider));

            this.Category = "Videogames";
            this.Answer = "Star Wars Outlaws";
            this.Phrase = "A renegade from outer space";
            this.Answer_lower = Answer.ToLower();
            this.outputProvider = outputProvider;
            EncryptAnswerWithDashes(this.Answer);

        }

        public Puzzle(string category, string phrase, string answer, IOutputProvider outputProvider)
        {
            this.Category = category;
            this.Answer = answer;
            this.Phrase = phrase;
            this.Answer_lower = Answer.ToLower();
            this.outputProvider = outputProvider;
            EncryptAnswerWithDashes(answer);
        }

        //Method to encrypt the puzzle answer as dashes, with spaces represented by 3 spaces
        public void EncryptAnswerWithDashes(string answer)
        {
            var encrypted = new StringBuilder();

            foreach (char c in answer)
            {
                if (c == ' ')
                {
                    // Add 3 spaces to overemphasize a space between words
                    encrypted.Append(c);
                }
                else
                {
                    // Add a dash for each character
                    encrypted.Append("-");
                }
            }
            this.Puzzle_string = encrypted.ToString();
        }

        public void DisplayPuzzle()
        {
            outputProvider.WriteLine();
            outputProvider.WriteLine(this.Puzzle_string);
            outputProvider.WriteLine();
        }

        public void DisplayHints()
        {
            outputProvider.WriteLine();
            outputProvider.WriteLine($"Category: {this.Category}");
            outputProvider.WriteLine($"Phrase: {this.Phrase}");
            outputProvider.WriteLine();
        }
        public bool CheckGuess(string guess)
        {
            return guess.ToLower() == Answer.ToLower();
        }

        public bool CheckLetterGuess(char guess)
        {
            CorrectGuesses = 0;
            string answer_lower = Answer.ToLower();
            var sb = new StringBuilder();
            for (int i = 0; i < Answer.Length; i++)
            {

                if (Puzzle_string[i] == '-')
                {
                    if (Answer_lower[i] == guess)
                    {
                        sb.Append(guess);
                        CorrectGuesses++;
                    }
                    else
                    {
                        sb.Append(Puzzle_string[i]);
                    }
                }
                else
                {
                    sb.Append(Puzzle_string[i]);
                }

            }
            if (CorrectGuesses > 0)
            {
                Puzzle_string = sb.ToString();
                return true;
            }
            return false;
        }
    }
}